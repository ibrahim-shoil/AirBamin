"""
WinUI 3 Conversion Test Script
Verifies that all required dependencies and components are working
"""

import sys
from pathlib import Path

def test_python_version():
    """Test Python version"""
    print("1. Testing Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 7:
        print(f"   ✅ Python {version.major}.{version.minor}.{version.micro} OK")
        return True
    else:
        print(f"   ❌ Python {version.major}.{version.minor}.{version.micro} - Need 3.7+")
        return False


def test_pythonnet():
    """Test Python.NET installation"""
    print("\n2. Testing Python.NET...")
    try:
        import clr
        print(f"   ✅ Python.NET {clr.__version__} installed")
        return True
    except ImportError as e:
        print(f"   ❌ Python.NET not installed: {e}")
        print("      Run: pip install pythonnet")
        return False


def test_dotnet():
    """Test .NET SDK availability"""
    print("\n3. Testing .NET SDK...")
    try:
        import subprocess
        result = subprocess.run(
            ["dotnet", "--list-sdks"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            sdks = result.stdout.strip().split('\n')
            print(f"   ✅ Found {len(sdks)} .NET SDK(s):")
            for sdk in sdks[:3]:  # Show first 3
                print(f"      - {sdk}")
            return True
        else:
            print("   ❌ No .NET SDKs found")
            print("      Download: https://dotnet.microsoft.com/download")
            return False
    except FileNotFoundError:
        print("   ❌ .NET SDK not installed or not in PATH")
        print("      Download: https://dotnet.microsoft.com/download/dotnet/6.0")
        return False
    except Exception as e:
        print(f"   ⚠️  Could not check .NET: {e}")
        return False


def test_winui():
    """Test WinUI 3 availability"""
    print("\n4. Testing WinUI 3...")
    try:
        import clr
        clr.AddReference("System")
        print("   ✅ System assembly loaded")
        
        try:
            clr.AddReference("Microsoft.WinUI")
            print("   ✅ Microsoft.WinUI assembly loaded")
            return True
        except Exception as e:
            print(f"   ❌ Microsoft.WinUI not found: {e}")
            print("      Install Windows App SDK:")
            print("      winget install Microsoft.WindowsAppRuntime.1.5")
            print("      OR download: https://aka.ms/windowsappsdk/1.5/latest/windowsappruntimeinstall-x64.exe")
            return False
            
    except Exception as e:
        print(f"   ❌ Error loading assemblies: {e}")
        return False


def test_core_dependencies():
    """Test core application dependencies"""
    print("\n5. Testing core dependencies...")
    
    deps = {
        "qrcode": "QR code generation",
        "PIL": "Image processing (Pillow)",
        "psutil": "System utilities"
    }
    
    all_ok = True
    for module, description in deps.items():
        try:
            __import__(module)
            print(f"   ✅ {module} - {description}")
        except ImportError:
            print(f"   ❌ {module} not installed - {description}")
            all_ok = False
    
    return all_ok


def test_core_modules():
    """Test AirBamin core modules"""
    print("\n6. Testing AirBamin core modules...")
    
    # Add src to path
    src_path = Path(__file__).parent / "src"
    sys.path.insert(0, str(src_path))
    
    modules = {
        "core.config": "Configuration management",
        "core.license": "License manager",
        "core.qr_generator": "QR code generator",
        "server.transfer_server": "Transfer server"
    }
    
    all_ok = True
    for module, description in modules.items():
        try:
            __import__(module)
            print(f"   ✅ {module} - {description}")
        except ImportError as e:
            print(f"   ❌ {module} failed: {e}")
            all_ok = False
    
    return all_ok


def test_ui_modules():
    """Test WinUI 3 UI modules"""
    print("\n7. Testing WinUI 3 UI modules...")
    
    # Add src to path
    src_path = Path(__file__).parent / "src"
    sys.path.insert(0, str(src_path))
    
    try:
        from ui import winui_window
        print("   ✅ ui.winui_window loaded")
        
        if winui_window.WINUI_AVAILABLE:
            print("   ✅ WinUI 3 components available")
            return True
        else:
            print("   ⚠️  WinUI 3 not available (module loaded but WinUI missing)")
            return False
            
    except Exception as e:
        print(f"   ❌ Failed to load UI modules: {e}")
        return False


def test_resources():
    """Test resource files"""
    print("\n8. Testing resource files...")
    
    src_path = Path(__file__).parent / "src"
    resources = [
        src_path / "resources" / "web" / "upload.html",
        src_path / "resources" / "web" / "css" / "styles.css",
        src_path / "resources" / "web" / "js" / "app.js"
    ]
    
    all_ok = True
    for resource in resources:
        if resource.exists():
            print(f"   ✅ {resource.relative_to(src_path)}")
        else:
            print(f"   ❌ Missing: {resource.relative_to(src_path)}")
            all_ok = False
    
    return all_ok


def main():
    """Run all tests"""
    print("=" * 60)
    print("AirBamin WinUI 3 Conversion - Verification Test")
    print("=" * 60)
    
    results = []
    
    results.append(("Python Version", test_python_version()))
    results.append(("Python.NET", test_pythonnet()))
    results.append((".NET SDK", test_dotnet()))
    results.append(("WinUI 3", test_winui()))
    results.append(("Core Dependencies", test_core_dependencies()))
    results.append(("Core Modules", test_core_modules()))
    results.append(("UI Modules", test_ui_modules()))
    results.append(("Resource Files", test_resources()))
    
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    
    for name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status:10} - {name}")
    
    all_passed = all(passed for _, passed in results)
    
    print("\n" + "=" * 60)
    if all_passed:
        print("🎉 All tests passed! Ready to run WinUI 3 application.")
        print("\nTo start the app:")
        print("  cd src")
        print("  python main.py")
    else:
        print("⚠️  Some tests failed. Please fix the issues above.")
        print("\nQuick fixes:")
        print("  pip install -r requirements.txt")
        print("  winget install Microsoft.DotNet.SDK.6")
        print("  winget install Microsoft.WindowsAppRuntime.1.5")
    print("=" * 60)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
