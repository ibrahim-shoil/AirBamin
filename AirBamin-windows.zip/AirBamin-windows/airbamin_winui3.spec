# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for AirBamin WinUI 3 Application
Creates a standalone Windows executable with all dependencies bundled

Usage:
    pyinstaller airbamin_winui3.spec
"""

import sys
from pathlib import Path

block_cipher = None

# Project paths
project_root = Path(SPECPATH)
src_dir = project_root / 'src'

# Data files to include
datas = [
    # Web resources for mobile upload interface
    (str(src_dir / 'resources' / 'web'), 'resources/web'),
    
    # Icon (if exists)
    # (str(src_dir / 'resources' / 'icon.ico'), 'resources'),
]

# Hidden imports needed for WinUI 3
hiddenimports = [
    'clr',
    'pythonnet',
    'System',
    'System.Runtime',
    'Microsoft.UI.Xaml',
    'Microsoft.UI.Xaml.Controls',
    'Microsoft.UI.Xaml.Media',
    'Microsoft.UI',
    'qrcode',
    'qrcode.image',
    'qrcode.image.pil',
    'PIL',
    'PIL.Image',
    'psutil',
]

# Core modules
core_modules = [
    'core.config',
    'core.license',
    'core.qr_generator',
    'server.transfer_server',
    'ui.winui_window',
    'ui.winui_dialogs',
]

hiddenimports.extend(core_modules)

a = Analysis(
    [str(src_dir / 'main.py')],
    pathex=[str(src_dir)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude PyQt6 to reduce size (we're using WinUI 3)
        'PyQt6',
        'PyQt6.QtCore',
        'PyQt6.QtGui',
        'PyQt6.QtWidgets',
        'PyQt6.QtWebEngineCore',
        'PyQt6.QtWebEngineWidgets',
        
        # Exclude other heavy unnecessary modules
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
        'tkinter',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='AirBamin',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # GUI application (no console window)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # Set to 'resources/icon.ico' if you have an icon
    version='file_version_info.txt',  # Optional: version info
)

# Optional: Create a COLLECT for one-folder distribution (smaller size when uncompressed)
# Uncomment below if you prefer folder distribution over single exe
"""
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='AirBamin'
)
"""
