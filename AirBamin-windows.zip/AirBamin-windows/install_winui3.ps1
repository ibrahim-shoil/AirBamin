# AirBamin WinUI 3 - Automated Installation Script
# Run this script to install all required dependencies

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "AirBamin WinUI 3 - Automated Installation" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "⚠️  Note: Some installations may require administrator privileges." -ForegroundColor Yellow
    Write-Host "   If installation fails, run PowerShell as Administrator." -ForegroundColor Yellow
    Write-Host ""
}

# Function to check if command exists
function Test-Command {
    param($Command)
    $null -ne (Get-Command $Command -ErrorAction SilentlyContinue)
}

# Step 1: Check Python
Write-Host "1. Checking Python..." -ForegroundColor Green
if (Test-Command python) {
    $pythonVersion = python --version
    Write-Host "   ✅ $pythonVersion" -ForegroundColor Green
} else {
    Write-Host "   ❌ Python not found!" -ForegroundColor Red
    Write-Host "      Please install Python 3.7+ first" -ForegroundColor Red
    exit 1
}

# Step 2: Check/Install winget
Write-Host ""
Write-Host "2. Checking winget (Windows Package Manager)..." -ForegroundColor Green
if (Test-Command winget) {
    Write-Host "   ✅ winget available" -ForegroundColor Green
    $useWinget = $true
} else {
    Write-Host "   ⚠️  winget not available" -ForegroundColor Yellow
    Write-Host "      Will use manual download method" -ForegroundColor Yellow
    $useWinget = $false
}

# Step 3: Install Python dependencies
Write-Host ""
Write-Host "3. Installing Python dependencies..." -ForegroundColor Green
try {
    python -m pip install --upgrade pip | Out-Null
    python -m pip install -r requirements.txt
    Write-Host "   ✅ Python packages installed" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Failed to install Python packages: $_" -ForegroundColor Red
}

# Step 4: Check/Install .NET SDK
Write-Host ""
Write-Host "4. Checking .NET SDK..." -ForegroundColor Green
if (Test-Command dotnet) {
    $dotnetVersion = dotnet --version
    Write-Host "   ✅ .NET SDK $dotnetVersion installed" -ForegroundColor Green
} else {
    Write-Host "   ❌ .NET SDK not found. Installing..." -ForegroundColor Yellow
    
    if ($useWinget) {
        Write-Host "   Installing via winget..." -ForegroundColor Cyan
        try {
            winget install Microsoft.DotNet.SDK.8 --silent --accept-package-agreements --accept-source-agreements
            Write-Host "   ✅ .NET SDK installed via winget" -ForegroundColor Green
            Write-Host "   ⚠️  Please restart your terminal to use 'dotnet' command" -ForegroundColor Yellow
        } catch {
            Write-Host "   ❌ winget installation failed: $_" -ForegroundColor Red
            Write-Host "   Please install manually: https://dotnet.microsoft.com/download/dotnet/8.0" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   Please download and install .NET SDK manually:" -ForegroundColor Yellow
        Write-Host "   https://dotnet.microsoft.com/download/dotnet/8.0" -ForegroundColor Cyan
        Start-Process "https://dotnet.microsoft.com/download/dotnet/8.0"
    }
}

# Step 5: Check/Install Windows App SDK
Write-Host ""
Write-Host "5. Checking Windows App SDK..." -ForegroundColor Green

# Try to load WinUI assembly
try {
    python -c "import clr; clr.AddReference('Microsoft.WinUI'); print('OK')" 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   ✅ Windows App SDK (WinUI 3) installed" -ForegroundColor Green
    } else {
        throw "Not installed"
    }
} catch {
    Write-Host "   ❌ Windows App SDK not found. Installing..." -ForegroundColor Yellow
    
    if ($useWinget) {
        Write-Host "   Installing via winget..." -ForegroundColor Cyan
        try {
            winget install Microsoft.WindowsAppRuntime.1.5 --silent --accept-package-agreements --accept-source-agreements
            Write-Host "   ✅ Windows App SDK installed via winget" -ForegroundColor Green
        } catch {
            Write-Host "   ❌ winget installation failed: $_" -ForegroundColor Red
            Write-Host "   Trying direct download..." -ForegroundColor Yellow
        }
    }
    
    # If winget failed or not available, download directly
    if (-not $useWinget -or $LASTEXITCODE -ne 0) {
        Write-Host "   Downloading Windows App SDK installer..." -ForegroundColor Cyan
        $installerUrl = "https://aka.ms/windowsappsdk/1.5/latest/windowsappruntimeinstall-x64.exe"
        $installerPath = "$env:TEMP\WindowsAppSDK.exe"
        
        try {
            Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath
            Write-Host "   Downloaded to $installerPath" -ForegroundColor Green
            Write-Host "   Running installer..." -ForegroundColor Cyan
            Start-Process -FilePath $installerPath -ArgumentList "--quiet" -Wait
            Write-Host "   ✅ Windows App SDK installed" -ForegroundColor Green
            Remove-Item $installerPath -ErrorAction SilentlyContinue
        } catch {
            Write-Host "   ❌ Download/install failed: $_" -ForegroundColor Red
            Write-Host "   Please install manually:" -ForegroundColor Yellow
            Write-Host "   https://learn.microsoft.com/windows/apps/windows-app-sdk/downloads" -ForegroundColor Cyan
        }
    }
}

# Step 6: Install Visual C++ Redistributable (required for WinUI 3)
Write-Host ""
Write-Host "6. Checking Visual C++ Redistributable..." -ForegroundColor Green
$vcRedistInstalled = Test-Path "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"

if ($vcRedistInstalled) {
    Write-Host "   ✅ Visual C++ Redistributable installed" -ForegroundColor Green
} else {
    Write-Host "   ⚠️  Visual C++ Redistributable may be missing" -ForegroundColor Yellow
    Write-Host "   Installing latest version..." -ForegroundColor Cyan
    
    $vcRedistUrl = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
    $vcRedistPath = "$env:TEMP\vc_redist.x64.exe"
    
    try {
        Invoke-WebRequest -Uri $vcRedistUrl -OutFile $vcRedistPath
        Start-Process -FilePath $vcRedistPath -ArgumentList "/quiet", "/norestart" -Wait
        Write-Host "   ✅ Visual C++ Redistributable installed" -ForegroundColor Green
        Remove-Item $vcRedistPath -ErrorAction SilentlyContinue
    } catch {
        Write-Host "   ⚠️  Installation failed (may already be installed): $_" -ForegroundColor Yellow
    }
}

# Step 7: Run verification test
Write-Host ""
Write-Host "7. Running verification test..." -ForegroundColor Green
Write-Host ""
Write-Host "-----------------------------------------------------------" -ForegroundColor DarkGray

python test_winui_setup.py

Write-Host "-----------------------------------------------------------" -ForegroundColor DarkGray
Write-Host ""

# Summary
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Installation Complete!" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Green
Write-Host "1. If .NET SDK was just installed, restart your terminal" -ForegroundColor White
Write-Host "2. Run the test again: python test_winui_setup.py" -ForegroundColor White
Write-Host "3. If all tests pass, start the app:" -ForegroundColor White
Write-Host "      cd src" -ForegroundColor Cyan
Write-Host "      python main.py" -ForegroundColor Cyan
Write-Host ""
Write-Host "Documentation:" -ForegroundColor Green
Write-Host "- INSTALLATION.md  - Detailed installation guide" -ForegroundColor White
Write-Host "- WINUI3_CONVERSION.md - Architecture and features" -ForegroundColor White
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan

# Pause if running in a new window
if ($Host.UI.RawUI.KeyAvailable) {
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
