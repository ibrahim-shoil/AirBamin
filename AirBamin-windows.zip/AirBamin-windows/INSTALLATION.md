# AirBamin WinUI 3 - Installation Guide

## ✅ Current Status

Your Python environment is ready:
- ✅ Python 3.13.3 installed
- ✅ Python.NET 3.0.5 installed
- ✅ Core dependencies installed (qrcode, Pillow, psutil)
- ✅ All core modules working (config, license, server)
- ✅ Resource files present

## ⚠️ Missing Components

To run WinUI 3, you need:
1. ❌ .NET SDK 6.0+
2. ❌ Windows App SDK (WinUI 3 runtime)

## 🚀 Installation Steps

### Option 1: Automated Installation (Recommended)

Run the PowerShell installation script:

```powershell
cd D:\LIFE\PROGRAMING\FILE-TRANSFERE\AirBamin-windows
.\install_winui3.ps1
```

### Option 2: Manual Installation

#### Step 1: Install .NET 6 SDK

**Using winget:**
```powershell
winget install Microsoft.DotNet.SDK.6
```

**Manual download:**
- Visit: https://dotnet.microsoft.com/download/dotnet/6.0
- Download "SDK x64" for Windows
- Run installer

**Verify:**
```powershell
dotnet --version
# Should show 6.0.x or 8.0.x
```

#### Step 2: Install Windows App SDK

**Using winget:**
```powershell
winget install Microsoft.WindowsAppRuntime.1.5
```

**Manual download:**
- Visit: https://learn.microsoft.com/windows/apps/windows-app-sdk/downloads
- Download latest stable version (1.5+)
- Or direct link: https://aka.ms/windowsappsdk/1.5/latest/windowsappruntimeinstall-x64.exe
- Run installer

**Verify:**
```powershell
python -c "import clr; clr.AddReference('Microsoft.WinUI'); print('WinUI 3 OK')"
```

#### Step 3: Test Everything

```powershell
python test_winui_setup.py
```

All tests should pass ✅

#### Step 4: Run Application

```powershell
cd src
python main.py
```

## 🔄 Alternative: Use PyQt6 (Fallback)

If WinUI 3 doesn't work, you can fall back to PyQt6 native widgets:

```powershell
# Uncomment PyQt6 in requirements.txt
pip install PyQt6>=6.6.0

# Or use the old WebEngine version
pip install PyQt6-WebEngine>=6.6.0
```

Then run:
```powershell
cd src
python -c "from ui.main_window import *; import sys; from PyQt6.QtWidgets import QApplication; app = QApplication(sys.argv); win = MainWindow(); win.show(); sys.exit(app.exec())"
```

## 🐛 Troubleshooting

### Issue: dotnet command not found

**Solution:**
- Restart terminal after installing .NET SDK
- Or add to PATH manually:
  - `C:\Program Files\dotnet`

### Issue: Microsoft.WinUI assembly not found

**Solution:**
1. Verify Windows version: Windows 10 1809+ or Windows 11 required
2. Install Visual C++ Redistributable: https://aka.ms/vs/17/release/vc_redist.x64.exe
3. Reinstall Windows App SDK
4. Check Windows Update for latest patches

### Issue: Application starts but crashes

**Solution:**
- Check Event Viewer (Windows Logs → Application)
- Enable .NET diagnostics:
  ```powershell
  $env:COREHOST_TRACE=1
  python src/main.py
  ```

## 📊 System Requirements

- **OS:** Windows 10 version 1809+ or Windows 11
- **Python:** 3.7+ (you have 3.13.3 ✅)
- **.NET:** 6.0 or later
- **RAM:** 2GB minimum, 4GB recommended
- **Disk:** 500MB free space

## 🎯 Next Steps After Installation

1. Run `test_winui_setup.py` - all should pass
2. Run `python src/main.py` - app should launch
3. Test file transfer:
   - Choose WiFi or Hotspot mode
   - Scan QR code from phone
   - Upload a test file
4. Verify mobile interface works at `http://YOUR_PC_IP:8080/upload`

## 📱 Mobile Testing

Once the app is running:
1. Note your PC's IP address (shown in QR screen)
2. On your phone, scan the QR code or visit `http://PC_IP:8080/upload`
3. Upload a test file
4. Check `C:\Users\YOUR_NAME\AirBamin Uploads\` for the file

## 🏆 Success Checklist

- [ ] Python.NET installed (`pip list | Select-String pythonnet`)
- [ ] .NET SDK installed (`dotnet --version`)
- [ ] Windows App SDK installed (verify with test script)
- [ ] Test script passes all tests
- [ ] Application launches without errors
- [ ] QR code displays correctly
- [ ] Mobile upload page accessible
- [ ] File transfer works end-to-end

## 📞 Need Help?

If you encounter issues:

1. **Run diagnostics:**
   ```powershell
   python test_winui_setup.py > setup_log.txt 2>&1
   ```

2. **Check versions:**
   ```powershell
   python --version
   dotnet --version
   pip list
   ```

3. **Review documentation:**
   - See `WINUI3_CONVERSION.md` for architecture details
   - Check Microsoft docs: https://learn.microsoft.com/windows/apps/

---

## 🎉 Why WinUI 3?

**Before (PyQt6-WebEngine):**
- Heavy (~150MB with Chromium)
- Slow startup
- Browser-like appearance
- High memory usage

**After (WinUI 3 Native):**
- Lightweight (~30MB)
- Fast startup
- True Windows 11 look
- Low memory usage
- Better integration

**Mobile interface unchanged:**
- Still uses HTML for phone uploads
- Same QR code workflow
- Same transfer protocol

Ready to install? Run `.\install_winui3.ps1` or follow manual steps above!
