@echo off
echo Creating Windows Firewall rule for AirBamin...
echo.

netsh advfirewall firewall add rule name="AirBamin Server" dir=in action=allow protocol=TCP localport=8080 description="Allow incoming connections for AirBamin file transfer"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ✅ SUCCESS! Firewall rule created.
    echo Port 8080 is now open for incoming connections.
    echo.
    echo You can now use AirBamin without admin rights.
) else (
    echo.
    echo ❌ Failed to create firewall rule.
    echo Make sure you run this as Administrator.
)

echo.
pause
