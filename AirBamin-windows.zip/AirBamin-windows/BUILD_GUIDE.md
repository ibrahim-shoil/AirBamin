# Building AirBamin Standalone Executable

## Prerequisites

1. Install PyInstaller:
   ```powershell
   pip install pyinstaller
   ```

2. Ensure all dependencies are installed:
   ```powershell
   pip install -r requirements.txt
   ```

3. Test that the application runs:
   ```powershell
   cd src
   python main.py
   ```

## Build Instructions

### Option 1: Using PyInstaller Spec File (Recommended)

```powershell
# From AirBamin-windows directory
pyinstaller airbamin_winui3.spec
```

This creates:
- `dist/AirBamin.exe` - Single executable file

### Option 2: Command Line

```powershell
pyinstaller --name AirBamin `
    --windowed `
    --onefile `
    --add-data "src/resources/web;resources/web" `
    --hidden-import clr `
    --hidden-import pythonnet `
    --hidden-import qrcode `
    --hidden-import PIL `
    --hidden-import psutil `
    src/main.py
```

## Distribution Package

The executable requires additional runtime components on target machines:

### Required Runtimes (Must be installed on target PC)

1. **.NET 6.0 Runtime**
   - Download: https://dotnet.microsoft.com/download/dotnet/6.0/runtime
   - Or via winget: `winget install Microsoft.DotNet.Runtime.6`

2. **Windows App SDK Runtime**
   - Download: https://aka.ms/windowsappsdk/1.5/latest/windowsappruntimeinstall-x64.exe
   - Or via winget: `winget install Microsoft.WindowsAppRuntime.1.5`

3. **Visual C++ Redistributable**
   - Download: https://aka.ms/vs/17/release/vc_redist.x64.exe

### Creating an Installer

For easy distribution, create an installer that bundles everything:

#### Using Inno Setup (Recommended)

1. Install Inno Setup: https://jrsoftware.org/isinfo.php

2. Create `installer.iss`:
   ```inno
   [Setup]
   AppName=AirBamin
   AppVersion=1.0.0
   DefaultDirName={pf}\AirBamin
   DefaultGroupName=AirBamin
   OutputBaseFilename=AirBamin_Setup
   Compression=lzma2
   SolidCompression=yes
   
   [Files]
   Source: "dist\AirBamin.exe"; DestDir: "{app}"
   Source: "runtimes\*"; DestDir: "{tmp}"; Flags: ignoreversion
   
   [Icons]
   Name: "{group}\AirBamin"; Filename: "{app}\AirBamin.exe"
   Name: "{commondesktop}\AirBamin"; Filename: "{app}\AirBamin.exe"
   
   [Run]
   ; Install .NET Runtime
   Filename: "{tmp}\dotnet-runtime-6-x64.exe"; Parameters: "/quiet /norestart"; StatusMsg: "Installing .NET Runtime..."
   ; Install Windows App SDK
   Filename: "{tmp}\windowsappruntimeinstall-x64.exe"; Parameters: "--quiet"; StatusMsg: "Installing Windows App SDK..."
   ; Install VC++ Redistributable
   Filename: "{tmp}\vc_redist.x64.exe"; Parameters: "/quiet /norestart"; StatusMsg: "Installing Visual C++ Runtime..."
   ; Launch app
   Filename: "{app}\AirBamin.exe"; Description: "Launch AirBamin"; Flags: postinstall nowait skipifsilent
   ```

3. Compile: Right-click `installer.iss` → Compile

#### Using WiX Toolset

For MSI installers, use WiX: https://wixtoolset.org/

## Testing the Executable

1. **Test on build machine:**
   ```powershell
   cd dist
   .\AirBamin.exe
   ```

2. **Test on clean VM:**
   - Create Windows 10/11 VM
   - Install only runtimes (.NET, WinUI, VC++)
   - Copy `AirBamin.exe`
   - Run and verify all features

## Distribution Checklist

- [ ] Executable builds without errors
- [ ] Runs on build machine
- [ ] Tested on clean Windows install
- [ ] All screens display correctly
- [ ] QR code generation works
- [ ] File transfer works from mobile
- [ ] Settings persist correctly
- [ ] License activation works
- [ ] Installer includes all runtimes
- [ ] Icon displays correctly (if added)
- [ ] Code signed (optional, for SmartScreen)

## File Sizes

Expected sizes:
- `AirBamin.exe` (onefile): ~25-35 MB
- `AirBamin` folder (onedir): ~50-70 MB
- Full installer with runtimes: ~150-200 MB

## Optimization

### Reduce Executable Size

1. **Use UPX compression** (already enabled in spec):
   - Download: https://upx.github.io/
   - Add to PATH
   - PyInstaller will automatically use it

2. **Exclude unnecessary modules:**
   - Check `excludes` list in `airbamin_winui3.spec`
   - Add more if needed

3. **One-folder vs One-file:**
   - One-file: Slower startup, easier distribution
   - One-folder: Faster startup, more files

## Code Signing (Optional)

For production release, sign the executable to avoid SmartScreen warnings:

1. Get code signing certificate from CA (DigiCert, Sectigo, etc.)

2. Sign with `signtool`:
   ```powershell
   signtool sign /f "cert.pfx" /p "password" /t http://timestamp.digicert.com dist\AirBamin.exe
   ```

3. Or use `osslsigncode` on Linux/Mac

## Publishing

### Microsoft Store (Optional)

Convert to MSIX package:
```powershell
# Install MSIX Packaging Tool
winget install Microsoft.MSIXPackagingTool

# Package the exe
# Follow: https://learn.microsoft.com/windows/msix/packaging-tool/create-app-package
```

### GitHub Releases

1. Create GitHub release
2. Upload:
   - `AirBamin.exe` (standalone)
   - `AirBamin_Setup.exe` (installer)
   - `AirBamin_Portable.zip` (onedir version)

### Website Download

Host on your website with instructions:
```
Download AirBamin
- Standalone: AirBamin.exe (requires runtimes)
- Installer: AirBamin_Setup.exe (includes runtimes)
```

## Troubleshooting Build Issues

### "Module not found" errors

Add to `hiddenimports` in spec file:
```python
hiddenimports = [
    'missing.module.name',
]
```

### Missing DLLs

Add to `binaries` in spec file:
```python
binaries = [
    ('path/to/missing.dll', '.'),
]
```

### Resource files missing

Add to `datas` in spec file:
```python
datas = [
    ('src/resources', 'resources'),
]
```

### Large executable size

- Enable UPX compression
- Exclude unnecessary modules
- Remove debug info

## Post-Build Verification

Run through full test workflow:

1. Launch app
2. Choose WiFi mode
3. Scan QR from phone
4. Upload file from phone
5. Verify file saved to PC
6. Open settings
7. Change upload folder
8. Test license activation (with test key)
9. Check all UI elements display correctly

---

Ready to build? Run `pyinstaller airbamin_winui3.spec` from the project root!
