"""
AirBamin - Native Windows Application
Native desktop application for wireless file transfer
"""

import sys
import subprocess
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))


def configure_firewall():
    """Configure Windows Firewall to allow AirBamin server"""
    try:
        print("Checking Windows Firewall rules...")
        
        # Check if rule already exists
        check_cmd = 'netsh advfirewall firewall show rule name="AirBamin Server"'
        result = subprocess.run(check_cmd, shell=True, capture_output=True, text=True)
        
        if "No rules match" in result.stdout:
            print("Creating Windows Firewall rule for AirBamin...")
            
            # Add firewall rule for port 8080
            add_cmd = (
                'netsh advfirewall firewall add rule '
                'name="AirBamin Server" '
                'dir=in action=allow protocol=TCP localport=8080 '
                'description="Allow incoming connections for AirBamin file transfer"'
            )
            
            result = subprocess.run(add_cmd, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Firewall rule created successfully!")
                print("   Port 8080 is now open for incoming connections")
            else:
                print("⚠️ Could not create firewall rule automatically")
                print("   You may need to run as Administrator or manually allow port 8080")
        else:
            print("✅ Firewall rule already exists")
            
    except Exception as e:
        print(f"⚠️ Firewall configuration failed: {e}")
        print("   The app will still work if firewall is disabled or port 8080 is manually allowed")


def main():
    """Launch AirBamin native application"""
    print("AirBamin - Starting native application...")
    
    # Configure firewall first
    configure_firewall()
    
    # Try WinUI 3 first
    try:
        from ui.winui_window import run_app, WINUI_AVAILABLE
        if WINUI_AVAILABLE:
            print("Launching WinUI 3 interface...")
            run_app()
            return
        else:
            print("WinUI 3 not available, using PyQt6 native widgets...")
    except Exception as e:
        print(f"WinUI 3 not available: {e}")
        print("Using PyQt6 native widgets...")
    
    # Fallback to PyQt6 native widgets
    try:
        from ui.pyqt_native_window import run_pyqt_app
        print("Launching PyQt6 native interface...")
        run_pyqt_app()
    except ImportError as e:
        print(f"PyQt6 not available: {e}")
        print("\nNo UI framework available!")
        print("\nPlease install either:")
        print("  1. WinUI 3:")
        print("     - winget install Microsoft.DotNet.SDK.8")
        print("     - winget install Microsoft.WindowsAppRuntime.1.5")
        print("  2. PyQt6:")
        print("     - pip install PyQt6")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
