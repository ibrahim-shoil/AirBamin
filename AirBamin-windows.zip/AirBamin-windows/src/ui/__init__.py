"""UI package initialization"""
