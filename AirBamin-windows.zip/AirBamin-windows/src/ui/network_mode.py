"""
Network Selection Dialog
Choose between WiFi network or Phone Hotspot
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QRadioButton, QButtonGroup, QWidget)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class NetworkModeDialog(QDialog):
    """Dialog to select network mode on startup"""
    
    MODE_WIFI = "wifi"
    MODE_HOTSPOT = "hotspot"
    
    def __init__(self, parent=None, show_back_button=False):
        super().__init__(parent)
        self.selected_mode = self.MODE_WIFI
        self.show_back_button = show_back_button
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        self.setWindowTitle("AirBamin - Network Setup")
        self.resize(750, 850)
        
        # Center on screen
        self.center_on_screen()
        
        self.setStyleSheet("""
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #1e40af, stop:1 #3b82f6);
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(35)
        layout.setContentsMargins(60, 60, 60, 60)
        
        # Title
        title = QLabel("Choose Connection Method")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            font-size: 42px;
            font-weight: bold;
            color: white;
            margin-bottom: 20px;
            letter-spacing: 2px;
        """)
        layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Select how your phone will connect to this PC")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("font-size: 18px; color: #dbeafe; margin-bottom: 40px; font-weight: 500;")
        layout.addWidget(subtitle)
        
        # Button group for radio buttons
        self.button_group = QButtonGroup(self)
        
        # Option 1: Same WiFi Network
        wifi_option = self.create_option_card(
            title="Same WiFi Network",
            description="Both devices connected to same WiFi router",
            note="Stable connection, may be slower",
            badge="Recommended",
            mode=self.MODE_WIFI,
            checked=True
        )
        layout.addWidget(wifi_option)
        
        # Option 2: Phone Hotspot
        hotspot_option = self.create_option_card(
            title="Phone Hotspot",
            description="Connect PC to your phone's mobile hotspot",
            note="Faster transfer speeds",
            badge="Best Performance",
            mode=self.MODE_HOTSPOT,
            checked=False
        )
        layout.addWidget(hotspot_option)
        
        layout.addStretch()
        
        # Button container
        button_container = QHBoxLayout()
        button_container.setSpacing(15)
        
        # Back button (only show if coming from main window)
        if self.show_back_button:
            back_btn = QPushButton("← Back")
            back_btn.clicked.connect(self.reject)
            back_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(255, 255, 255, 0.2);
                    color: white;
                    border: 2px solid white;
                    padding: 18px 40px;
                    border-radius: 16px;
                    font-size: 18px;
                    font-weight: bold;
                    min-height: 60px;
                    min-width: 150px;
                }
                QPushButton:hover {
                    background-color: rgba(255, 255, 255, 0.3);
                }
                QPushButton:pressed {
                    background-color: rgba(255, 255, 255, 0.1);
                }
            """)
            button_container.addWidget(back_btn)
        
        # Continue button
        continue_btn = QPushButton("Continue")
        continue_btn.clicked.connect(self.accept)
        continue_btn.setStyleSheet("""
            QPushButton {
                background-color: #fbbf24;
                color: #1e3a8a;
                border: none;
                padding: 20px 60px;
                border-radius: 16px;
                font-size: 20px;
                font-weight: bold;
                min-height: 60px;
                min-width: 200px;
            }
            QPushButton:hover {
                background-color: #f59e0b;
            }
            QPushButton:pressed {
                background-color: #d97706;
            }
        """)
        button_container.addWidget(continue_btn)
        
        layout.addLayout(button_container, 0)
        
    def create_option_card(self, title, description, note, badge, mode, checked=False):
        """Create an option card with radio button"""
        card = QWidget()
        card.setMinimumHeight(200)
        card.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 24px;
            }
            QWidget:hover {
                background-color: #f0f9ff;
            }
        """)
        
        main_layout = QVBoxLayout(card)
        main_layout.setContentsMargins(40, 30, 40, 30)
        main_layout.setSpacing(14)
        
        # Top row: Radio + Title
        top_row = QHBoxLayout()
        top_row.setSpacing(25)
        
        # Radio button
        radio = QRadioButton()
        radio.setChecked(checked)
        radio.setStyleSheet("""
            QRadioButton::indicator {
                width: 32px;
                height: 32px;
            }
            QRadioButton::indicator:unchecked {
                border: 3px solid #3b82f6;
                border-radius: 16px;
                background-color: white;
            }
            QRadioButton::indicator:checked {
                border: 3px solid #3b82f6;
                border-radius: 16px;
                background-color: #3b82f6;
            }
        """)
        
        # Store mode in radio button
        radio.toggled.connect(lambda checked, m=mode: self.on_mode_selected(m) if checked else None)
        self.button_group.addButton(radio)
        
        top_row.addWidget(radio)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            font-size: 26px;
            font-weight: bold;
            color: #1e3a8a;
        """)
        top_row.addWidget(title_label, 1)
        
        main_layout.addLayout(top_row)
        
        # Description
        desc_label = QLabel(description)
        desc_label.setStyleSheet("""
            font-size: 18px; 
            color: #475569; 
            font-weight: 500;
            margin-left: 57px;
        """)
        desc_label.setWordWrap(True)
        main_layout.addWidget(desc_label)
        
        # Note
        note_label = QLabel(note)
        note_label.setStyleSheet("""
            font-size: 17px; 
            color: #64748b;
            margin-left: 57px;
        """)
        note_label.setWordWrap(True)
        main_layout.addWidget(note_label)
        
        # Badge
        if badge:
            badge_label = QLabel(badge)
            badge_label.setStyleSheet("""
                background-color: #3b82f6;
                color: white;
                padding: 12px 24px;
                border-radius: 16px;
                font-size: 15px;
                font-weight: bold;
            """)
            badge_label.setMaximumWidth(240)
            badge_container = QHBoxLayout()
            badge_container.setContentsMargins(57, 8, 0, 0)
            badge_container.addWidget(badge_label)
            badge_container.addStretch()
            main_layout.addLayout(badge_container)
        
        # Make entire card clickable
        card.mousePressEvent = lambda e: radio.setChecked(True)
        
        return card
        
    def center_on_screen(self):
        """Center the dialog on screen"""
        from PyQt6.QtGui import QScreen
        screen = self.screen().availableGeometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)
    
    def on_mode_selected(self, mode):
        """Handle mode selection"""
        self.selected_mode = mode
        
    def get_selected_mode(self):
        """Get selected network mode"""
        return self.selected_mode
