"""
Settings Dialog
User preferences and configuration
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QLineEdit, QCheckBox, QFileDialog,
                             QGroupBox, QFormLayout)
from PyQt6.QtCore import Qt
from pathlib import Path


class SettingsDialog(QDialog):
    """Settings dialog window"""
    
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        self.setWindowTitle("Settings")
        self.setMinimumSize(500, 400)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        
        # Upload Folder Settings
        folder_group = QGroupBox("Upload Settings")
        folder_layout = QFormLayout()
        
        self.folder_input = QLineEdit(str(self.config.get_upload_folder()))
        self.folder_input.setReadOnly(True)
        
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.folder_input)
        
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browse_folder)
        folder_row.addWidget(browse_btn)
        
        folder_layout.addRow("Save files to:", folder_row)
        folder_group.setLayout(folder_layout)
        layout.addWidget(folder_group)
        
        # Server Settings
        server_group = QGroupBox("Server Settings")
        server_layout = QFormLayout()
        
        self.port_input = QLineEdit(str(self.config.get_port()))
        self.port_input.setPlaceholderText("8080")
        server_layout.addRow("Port:", self.port_input)
        
        server_group.setLayout(server_layout)
        layout.addWidget(server_group)
        
        # General Settings
        general_group = QGroupBox("General")
        general_layout = QVBoxLayout()
        
        self.auto_start_cb = QCheckBox("Start with Windows")
        self.auto_start_cb.setChecked(self.config.get("auto_start", False))
        general_layout.addWidget(self.auto_start_cb)
        
        self.minimize_tray_cb = QCheckBox("Minimize to system tray")
        self.minimize_tray_cb.setChecked(self.config.get("minimize_to_tray", True))
        general_layout.addWidget(self.minimize_tray_cb)
        
        general_group.setLayout(general_layout)
        layout.addWidget(general_group)
        
        layout.addStretch()
        
        # Buttons
        buttons = QHBoxLayout()
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self.save_settings)
        save_btn.setStyleSheet("""
            QPushButton {
                background-color: #2563eb;
                color: white;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
        """)
        
        buttons.addStretch()
        buttons.addWidget(cancel_btn)
        buttons.addWidget(save_btn)
        
        layout.addLayout(buttons)
        
    def browse_folder(self):
        """Browse for upload folder"""
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select Upload Folder",
            str(self.config.get_upload_folder())
        )
        
        if folder:
            self.folder_input.setText(folder)
            
    def save_settings(self):
        """Save settings"""
        try:
            # Save upload folder
            self.config.set_upload_folder(Path(self.folder_input.text()))
            
            # Save port
            port = int(self.port_input.text())
            if 1024 <= port <= 65535:
                self.config.set("port", port)
            
            # Save checkboxes
            self.config.set("auto_start", self.auto_start_cb.isChecked())
            self.config.set("minimize_to_tray", self.minimize_tray_cb.isChecked())
            
            self.accept()
        except ValueError:
            # Invalid port number
            pass
