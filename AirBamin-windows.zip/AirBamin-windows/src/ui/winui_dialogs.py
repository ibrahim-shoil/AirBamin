"""
WinUI 3 Activation and Settings Dialogs
Native Windows dialogs for license activation and app settings
"""

from __future__ import annotations
from typing import Optional

try:
    import clr
    clr.AddReference("System")
    clr.AddReference("Microsoft.WinUI")
    clr.AddReference("Microsoft.Windows.SDK.NET")
    
    from System import String, Uri
    from Microsoft.UI.Xaml import Window, Controls, Visibility
    from Microsoft.UI.Xaml.Controls import (
        StackPanel, TextBlock, Button, TextBox, 
        ContentDialog, ContentDialogResult
    )
    from Microsoft.UI import Colors
    from Microsoft.UI.Xaml.Media import SolidColorBrush
    import System.Windows
    
    WINUI_AVAILABLE = True
except Exception:
    WINUI_AVAILABLE = False


class ActivationDialogWinUI(Window):
    """License activation dialog for WinUI 3"""
    
    def __init__(self, license_manager, parent=None):
        if not WINUI_AVAILABLE:
            raise RuntimeError("WinUI 3 is not available")
            
        super().__init__()
        self.license_manager = license_manager
        self.result = None
        
        self.Title = "Activate AirBamin Pro"
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize dialog UI"""
        container = StackPanel()
        container.Padding = System.Windows.Thickness(40)
        container.Spacing = 20
        
        # Title
        title = TextBlock()
        title.Text = "⭐ Upgrade to Pro"
        title.FontSize = 28
        title.FontWeight = System.Windows.FontWeights.Bold
        title.Foreground = SolidColorBrush(Colors.Green)
        title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Features list
        features_title = TextBlock()
        features_title.Text = "Pro Features:"
        features_title.FontSize = 18
        features_title.FontWeight = System.Windows.FontWeights.SemiBold
        
        features = StackPanel()
        features.Spacing = 10
        features.Margin = System.Windows.Thickness(0, 10, 0, 10)
        
        feature_items = [
            "✓ Unlimited transfers - No daily limits",
            "✓ Unlimited file size - Transfer files of any size",
            "✓ Faster speeds - Optimized performance",
            "✓ Custom save locations - Choose where files go",
            "✓ Transfer history - Track all your transfers",
            "✓ Lifetime updates - Never pay again"
        ]
        
        for item in feature_items:
            feature = TextBlock()
            feature.Text = item
            feature.FontSize = 14
            features.Children.Add(feature)
        
        # Price
        price = TextBlock()
        price.Text = "$29.99 - One-time payment"
        price.FontSize = 20
        price.FontWeight = System.Windows.FontWeights.Bold
        price.Foreground = SolidColorBrush(Colors.Green)
        price.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        price.Margin = System.Windows.Thickness(0, 10, 0, 10)
        
        # Purchase button
        purchase_btn = Button()
        purchase_btn.Content = "🛒 Purchase License Key"
        purchase_btn.FontSize = 16
        purchase_btn.Padding = System.Windows.Thickness(20, 10, 20, 10)
        purchase_btn.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        purchase_btn.Click += self.on_purchase_click
        
        # Separator
        separator = TextBlock()
        separator.Text = "Already purchased? Enter your license key:"
        separator.FontSize = 14
        separator.Foreground = SolidColorBrush(Colors.Gray)
        separator.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        separator.Margin = System.Windows.Thickness(0, 20, 0, 0)
        
        # License key input
        key_label = TextBlock()
        key_label.Text = "License Key:"
        key_label.FontWeight = System.Windows.FontWeights.SemiBold
        
        self.key_input = TextBox()
        self.key_input.PlaceholderText = "AIRBM-XXXXX-XXXXX-XXXXX-XXXXX"
        self.key_input.FontSize = 14
        
        # Status message
        self.status_text = TextBlock()
        self.status_text.Text = ""
        self.status_text.FontSize = 14
        self.status_text.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        self.status_text.Visibility = Visibility.Collapsed
        
        # Buttons
        button_panel = StackPanel()
        button_panel.Orientation = Controls.Orientation.Horizontal
        button_panel.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        button_panel.Spacing = 15
        
        activate_btn = Button()
        activate_btn.Content = "Activate"
        activate_btn.FontSize = 16
        activate_btn.Padding = System.Windows.Thickness(30, 10, 30, 10)
        activate_btn.Click += self.on_activate_click
        
        cancel_btn = Button()
        cancel_btn.Content = "Cancel"
        cancel_btn.FontSize = 16
        cancel_btn.Padding = System.Windows.Thickness(30, 10, 30, 10)
        cancel_btn.Click += self.on_cancel_click
        
        button_panel.Children.Add(activate_btn)
        button_panel.Children.Add(cancel_btn)
        
        # Add all elements
        container.Children.Add(title)
        container.Children.Add(features_title)
        container.Children.Add(features)
        container.Children.Add(price)
        container.Children.Add(purchase_btn)
        container.Children.Add(separator)
        container.Children.Add(key_label)
        container.Children.Add(self.key_input)
        container.Children.Add(self.status_text)
        container.Children.Add(button_panel)
        
        self.Content = container
        
    def on_purchase_click(self, sender, e):
        """Open purchase page"""
        import webbrowser
        webbrowser.open("https://yourdomain.com/purchase")  # Replace with actual URL
        
    def on_activate_click(self, sender, e):
        """Activate license key"""
        key = self.key_input.Text.strip()
        
        if not key:
            self.show_status("Please enter a license key", Colors.Red)
            return
            
        if self.license_manager.activate(key):
            self.show_status("License activated successfully!", Colors.Green)
            self.result = True
            # Close after 1 second
            import threading
            threading.Timer(1.0, lambda: self.DispatcherQueue.TryEnqueue(self.Close)).start()
        else:
            self.show_status("Invalid license key. Please check and try again.", Colors.Red)
            
    def on_cancel_click(self, sender, e):
        """Cancel activation"""
        self.result = False
        self.Close()
        
    def show_status(self, message: str, color):
        """Show status message"""
        self.status_text.Text = message
        self.status_text.Foreground = SolidColorBrush(color)
        self.status_text.Visibility = Visibility.Visible


class SettingsDialogWinUI(Window):
    """Settings dialog for WinUI 3"""
    
    def __init__(self, config, parent=None):
        if not WINUI_AVAILABLE:
            raise RuntimeError("WinUI 3 is not available")
            
        super().__init__()
        self.config = config
        self.result = None
        
        self.Title = "AirBamin Settings"
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize settings UI"""
        container = StackPanel()
        container.Padding = System.Windows.Thickness(40)
        container.Spacing = 25
        
        # Title
        title = TextBlock()
        title.Text = "Settings"
        title.FontSize = 28
        title.FontWeight = System.Windows.FontWeights.Bold
        title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Upload folder setting
        upload_section = StackPanel()
        upload_section.Spacing = 10
        
        upload_label = TextBlock()
        upload_label.Text = "Upload Folder:"
        upload_label.FontSize = 16
        upload_label.FontWeight = System.Windows.FontWeights.SemiBold
        
        upload_path_panel = StackPanel()
        upload_path_panel.Orientation = Controls.Orientation.Horizontal
        upload_path_panel.Spacing = 10
        
        self.upload_path_text = TextBox()
        self.upload_path_text.Text = self.config.get_upload_folder()
        self.upload_path_text.FontSize = 14
        self.upload_path_text.Width = 400
        self.upload_path_text.IsReadOnly = True
        
        browse_btn = Button()
        browse_btn.Content = "Browse..."
        browse_btn.Click += self.on_browse_click
        
        upload_path_panel.Children.Add(self.upload_path_text)
        upload_path_panel.Children.Add(browse_btn)
        
        upload_section.Children.Add(upload_label)
        upload_section.Children.Add(upload_path_panel)
        
        # Port setting
        port_section = StackPanel()
        port_section.Spacing = 10
        
        port_label = TextBlock()
        port_label.Text = "Server Port:"
        port_label.FontSize = 16
        port_label.FontWeight = System.Windows.FontWeights.SemiBold
        
        self.port_input = TextBox()
        self.port_input.Text = str(self.config.get_port())
        self.port_input.FontSize = 14
        self.port_input.Width = 150
        
        port_help = TextBlock()
        port_help.Text = "Default: 8080"
        port_help.FontSize = 12
        port_help.Foreground = SolidColorBrush(Colors.Gray)
        
        port_section.Children.Add(port_label)
        port_section.Children.Add(self.port_input)
        port_section.Children.Add(port_help)
        
        # Status message
        self.status_text = TextBlock()
        self.status_text.Text = ""
        self.status_text.FontSize = 14
        self.status_text.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        self.status_text.Visibility = Visibility.Collapsed
        
        # Buttons
        button_panel = StackPanel()
        button_panel.Orientation = Controls.Orientation.Horizontal
        button_panel.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        button_panel.Spacing = 15
        button_panel.Margin = System.Windows.Thickness(0, 20, 0, 0)
        
        save_btn = Button()
        save_btn.Content = "Save"
        save_btn.FontSize = 16
        save_btn.Padding = System.Windows.Thickness(30, 10, 30, 10)
        save_btn.Click += self.on_save_click
        
        cancel_btn = Button()
        cancel_btn.Content = "Cancel"
        cancel_btn.FontSize = 16
        cancel_btn.Padding = System.Windows.Thickness(30, 10, 30, 10)
        cancel_btn.Click += self.on_cancel_click
        
        button_panel.Children.Add(save_btn)
        button_panel.Children.Add(cancel_btn)
        
        # Add all elements
        container.Children.Add(title)
        container.Children.Add(upload_section)
        container.Children.Add(port_section)
        container.Children.Add(self.status_text)
        container.Children.Add(button_panel)
        
        self.Content = container
        
    def on_browse_click(self, sender, e):
        """Browse for upload folder"""
        # Note: WinUI 3 file picker requires more complex setup
        # For now, user can manually edit the path
        # TODO: Implement Windows.Storage.Pickers.FolderPicker
        self.show_status("Folder picker not yet implemented. Edit config file manually.", Colors.Orange)
        
    def on_save_click(self, sender, e):
        """Save settings"""
        try:
            # Validate port
            port = int(self.port_input.Text)
            if port < 1024 or port > 65535:
                self.show_status("Port must be between 1024 and 65535", Colors.Red)
                return
                
            # Save settings
            self.config.set_port(port)
            self.config.set_upload_folder(self.upload_path_text.Text)
            
            self.show_status("Settings saved successfully!", Colors.Green)
            self.result = True
            
            # Close after 1 second
            import threading
            threading.Timer(1.0, lambda: self.DispatcherQueue.TryEnqueue(self.Close)).start()
            
        except ValueError:
            self.show_status("Invalid port number", Colors.Red)
        except Exception as e:
            self.show_status(f"Error saving settings: {e}", Colors.Red)
            
    def on_cancel_click(self, sender, e):
        """Cancel settings"""
        self.result = False
        self.Close()
        
    def show_status(self, message: str, color):
        """Show status message"""
        self.status_text.Text = message
        self.status_text.Foreground = SolidColorBrush(color)
        self.status_text.Visibility = Visibility.Visible
