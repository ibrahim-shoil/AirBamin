"""
Welcome Screen for AirBamin
First screen shown when app opens
"""

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt, pyqtSignal


class WelcomeScreen(QWidget):
    """Welcome screen widget"""
    
    get_started = pyqtSignal()  # Signal when user clicks Get Started
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(40)
        layout.setContentsMargins(80, 80, 80, 80)
        
        # Welcome Title
        title = QLabel("AirBamin File Transfer")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            font-size: 72px;
            font-weight: bold;
            color: white;
            margin-bottom: 25px;
            letter-spacing: 4px;
        """)
        layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Professional Wireless File Transfer Solution")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("""
            font-size: 26px;
            color: white;
            font-weight: 600;
            margin-bottom: 35px;
        """)
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        
        # Features
        features = QLabel("Fast | Secure | Reliable")
        features.setAlignment(Qt.AlignmentFlag.AlignCenter)
        features.setStyleSheet("""
            font-size: 24px;
            color: white;
            font-weight: 700;
            margin-bottom: 50px;
        """)
        layout.addWidget(features)
        
        # Get Started Button
        get_started_btn = QPushButton("Get Started")
        get_started_btn.clicked.connect(self.get_started.emit)
        get_started_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #1e3a8a;
                border: none;
                padding: 30px 90px;
                border-radius: 20px;
                font-size: 28px;
                font-weight: bold;
                min-height: 80px;
                min-width: 350px;
            }
            QPushButton:hover {
                background-color: #fbbf24;
            }
            QPushButton:pressed {
                background-color: #f59e0b;
            }
        """)
        layout.addWidget(get_started_btn, 0, Qt.AlignmentFlag.AlignCenter)
        
        layout.addStretch()
