"""
Mode Selection Screen for AirBamin
Let user choose WiFi or Hotspot mode
"""

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt, pyqtSignal


class ModeSelectionScreen(QWidget):
    """Mode selection screen widget"""
    
    mode_selected = pyqtSignal(str)  # Signal with selected mode
    back_clicked = pyqtSignal()  # Signal when back is clicked
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        layout = QVBoxLayout(self)
        layout.setSpacing(40)
        layout.setContentsMargins(60, 40, 60, 60)
        
        # Back button
        back_btn = QPushButton("← Back")
        back_btn.clicked.connect(self.back_clicked.emit)
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #1e3a8a;
                border: none;
                padding: 15px 35px;
                border-radius: 12px;
                font-size: 18px;
                font-weight: bold;
                min-width: 130px;
            }
            QPushButton:hover {
                background-color: #fbbf24;
            }
        """)
        layout.addWidget(back_btn, 0, Qt.AlignmentFlag.AlignLeft)
        
        layout.addSpacing(20)
        
        # Title
        title = QLabel("Select Connection Method")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            font-size: 58px;
            font-weight: bold;
            color: white;
            margin-bottom: 25px;
            letter-spacing: 3px;
        """)
        layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Choose your preferred network connection type")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("""
            font-size: 24px;
            color: white;
            font-weight: 600;
            margin-bottom: 50px;
        """)
        layout.addWidget(subtitle)
        
        layout.addStretch()
        
        # Mode selection buttons container
        buttons_container = QWidget()
        buttons_layout = QVBoxLayout(buttons_container)
        buttons_layout.setSpacing(30)
        
        # WiFi Option
        wifi_card = self.create_mode_card(
            "WiFi Network",
            "Both devices connected to the same WiFi network",
            "Stable Connection | Ideal for Home and Office",
            "wifi"
        )
        buttons_layout.addWidget(wifi_card)
        
        # Hotspot Option
        hotspot_card = self.create_mode_card(
            "Mobile Hotspot",
            "Connect PC to your phone's mobile hotspot",
            "Maximum Transfer Speed | Best Performance",
            "hotspot"
        )
        buttons_layout.addWidget(hotspot_card)
        
        layout.addWidget(buttons_container)
        layout.addStretch()
        
    def create_mode_card(self, title, description, features, mode):
        """Create a mode selection card"""
        card = QPushButton()
        card.clicked.connect(lambda: self.mode_selected.emit(mode))
        card.setMinimumHeight(220)
        card.setStyleSheet("""
            QPushButton {
                background-color: #1e3a8a;
                border: 4px solid white;
                border-radius: 24px;
                text-align: left;
                padding: 40px;
            }
            QPushButton:hover {
                background-color: #2563eb;
                border: 4px solid #fbbf24;
            }
            QPushButton:pressed {
                background-color: #1d4ed8;
            }
        """)
        
        # Create layout for card content
        card_widget = QWidget(card)
        card_layout = QVBoxLayout(card_widget)
        card_layout.setSpacing(18)
        card_layout.setContentsMargins(0, 0, 0, 0)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            font-size: 38px;
            font-weight: bold;
            color: white;
        """)
        card_layout.addWidget(title_label)
        
        # Description
        desc_label = QLabel(description)
        desc_label.setStyleSheet("""
            font-size: 20px;
            color: white;
            font-weight: 600;
        """)
        desc_label.setWordWrap(True)
        card_layout.addWidget(desc_label)
        
        # Features
        features_label = QLabel(features)
        features_label.setStyleSheet("""
            font-size: 18px;
            color: #fbbf24;
            margin-top: 8px;
            font-weight: 700;
        """)
        card_layout.addWidget(features_label)
        
        return card
