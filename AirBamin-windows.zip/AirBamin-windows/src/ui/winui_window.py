"""
AirBamin Main Window - WinUI 3 Native Implementation
Uses Python.NET to create a native Windows 11 application with WinUI 3 controls
"""

from __future__ import annotations

import base64
import os
import socket
import threading
from io import BytesIO
from pathlib import Path
from typing import Optional, List, Tuple

import clr
clr.AddReference("System")
clr.AddReference("System.Runtime")

# Import WinRT projections for Windows App SDK / WinUI 3
# Note: Requires Windows App SDK to be installed
try:
    import System
    from System import Uri, String, Int32, Action, EventHandler
    from System.Threading import Thread, ThreadStart, ApartmentState
    
    # WinUI 3 namespaces (Microsoft.UI.Xaml)
    clr.AddReference("Microsoft.WinUI")
    clr.AddReference("Microsoft.Windows.SDK.NET")
    
    from Microsoft.UI.Xaml import Application, Window, Controls, Media, Visibility
    from Microsoft.UI.Xaml.Controls import (
        StackPanel, TextBlock, Button, Image, ProgressBar, 
        Grid, Border, ScrollViewer, ContentDialog
    )
    from Microsoft.UI.Xaml.Media import SolidColorBrush, ImageBrush
    from Microsoft.UI.Xaml.Media.Imaging import BitmapImage
    from Microsoft.UI import Colors
    from Microsoft.UI.Dispatching import DispatcherQueue
    
    WINUI_AVAILABLE = True
except Exception as e:
    WINUI_AVAILABLE = False
    print(f"WinUI 3 not available: {e}")
    print("Please install Windows App SDK and ensure Microsoft.WinUI package is available")

from core.config import Config
from core.license import LicenseManager
from core.qr_generator import QRGenerator
from server.transfer_server import TransferServer


class ServerThread(threading.Thread):
    """Run transfer server in background thread"""

    def __init__(self, port: int = 8080, callbacks=None) -> None:
        super().__init__(daemon=True)
        self.port = port
        self.server: Optional[TransferServer] = None
        self.callbacks = callbacks or {}

    def run(self) -> None:
        """Start the transfer server"""
        try:
            self.server = TransferServer(port=self.port)
            
            # Wire up callbacks
            if 'status_update' in self.callbacks:
                self.server.on_status_change = self.callbacks['status_update']
            if 'transfer_complete' in self.callbacks:
                self.server.on_transfer_complete = self.callbacks['transfer_complete']
            if 'upload_progress' in self.callbacks:
                self.server.on_upload_progress = self.callbacks['upload_progress']
            if 'client_connected' in self.callbacks:
                self.server.on_client_connected = self.callbacks['client_connected']
                
            self.server.start()
        except Exception as exc:
            if 'status_update' in self.callbacks:
                self.callbacks['status_update'](f"❌ Error: {exc}")


class AirBaminWindow(Window):
    """Main WinUI 3 application window"""
    
    def __init__(self):
        if not WINUI_AVAILABLE:
            raise RuntimeError("WinUI 3 is not available. Please install Windows App SDK.")
            
        super().__init__()
        
        # Core components
        self.config = Config()
        self.license_manager = LicenseManager()
        self.qr_generator = QRGenerator()
        self.server_thread: Optional[ServerThread] = None
        self.network_mode: Optional[str] = None
        
        # State tracking
        self.current_screen = "welcome"
        
        # UI initialization
        self.Title = "AirBamin - Easy File Transfer"
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize the UI layout"""
        # Main container
        self.root_grid = Grid()
        self.Content = self.root_grid
        
        # Create all screen containers
        self.welcome_screen = self.create_welcome_screen()
        self.mode_screen = self.create_mode_screen()
        self.qr_screen = self.create_qr_screen()
        
        # Add all screens to grid (only one visible at a time)
        self.root_grid.Children.Add(self.welcome_screen)
        self.root_grid.Children.Add(self.mode_screen)
        self.root_grid.Children.Add(self.qr_screen)
        
        # Show welcome screen initially
        self.show_screen("welcome")
        
    def create_welcome_screen(self) -> StackPanel:
        """Create welcome screen UI"""
        container = StackPanel()
        container.Padding = System.Windows.Thickness(40)
        container.Spacing = 30
        container.VerticalAlignment = System.Windows.VerticalAlignment.Center
        container.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Title
        title = TextBlock()
        title.Text = "AirBamin"
        title.FontSize = 48
        title.FontWeight = System.Windows.FontWeights.Bold
        title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Subtitle
        subtitle = TextBlock()
        subtitle.Text = "Transfer files from your phone to PC wirelessly"
        subtitle.FontSize = 18
        subtitle.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        subtitle.Foreground = SolidColorBrush(Colors.Gray)
        
        # Feature list
        features = StackPanel()
        features.Spacing = 15
        features.Margin = System.Windows.Thickness(0, 20, 0, 20)
        
        feature_texts = [
            "📱 Scan QR code from your phone",
            "⚡ Fast wireless transfer",
            "🔒 Secure local network connection",
            "📂 Automatic file organization"
        ]
        
        for feature_text in feature_texts:
            feature = TextBlock()
            feature.Text = feature_text
            feature.FontSize = 16
            features.Children.Add(feature)
        
        # Get Started button
        get_started_btn = Button()
        get_started_btn.Content = "Get Started"
        get_started_btn.FontSize = 18
        get_started_btn.Padding = System.Windows.Thickness(40, 15, 40, 15)
        get_started_btn.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        get_started_btn.Click += self.on_get_started_click
        
        # License badge
        license_badge = TextBlock()
        license_badge.Text = "PRO" if self.license_manager.is_pro() else "FREE"
        license_badge.FontSize = 14
        license_badge.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        license_badge.Foreground = SolidColorBrush(Colors.Orange if self.license_manager.is_pro() else Colors.Gray)
        self.welcome_license_badge = license_badge
        
        # Add all elements
        container.Children.Add(title)
        container.Children.Add(subtitle)
        container.Children.Add(features)
        container.Children.Add(get_started_btn)
        container.Children.Add(license_badge)
        
        return container
        
    def create_mode_screen(self) -> StackPanel:
        """Create mode selection screen UI"""
        container = StackPanel()
        container.Padding = System.Windows.Thickness(40)
        container.Spacing = 30
        
        # Title
        title = TextBlock()
        title.Text = "Choose Connection Mode"
        title.FontSize = 32
        title.FontWeight = System.Windows.FontWeights.Bold
        title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Mode buttons container
        modes = StackPanel()
        modes.Spacing = 20
        modes.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # WiFi Mode button
        wifi_btn = self.create_mode_button(
            "📶 WiFi Mode",
            "Connect when both devices are on the same WiFi network",
            lambda s, e: self.on_mode_selected("wifi")
        )
        
        # Hotspot Mode button
        hotspot_btn = self.create_mode_button(
            "📡 Hotspot Mode",
            "Connect PC to phone's mobile hotspot",
            lambda s, e: self.on_mode_selected("hotspot")
        )
        
        modes.Children.Add(wifi_btn)
        modes.Children.Add(hotspot_btn)
        
        # Back button
        back_btn = Button()
        back_btn.Content = "← Back"
        back_btn.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        back_btn.Margin = System.Windows.Thickness(0, 20, 0, 0)
        back_btn.Click += lambda s, e: self.show_screen("welcome")
        
        container.Children.Add(title)
        container.Children.Add(modes)
        container.Children.Add(back_btn)
        
        return container
        
    def create_mode_button(self, title_text: str, subtitle_text: str, click_handler) -> Border:
        """Create a styled mode selection button"""
        border = Border()
        border.Background = SolidColorBrush(Colors.WhiteSmoke)
        border.CornerRadius = System.Windows.CornerRadius(10)
        border.Padding = System.Windows.Thickness(30, 20, 30, 20)
        border.Width = 400
        
        button = Button()
        button.Background = SolidColorBrush(Colors.Transparent)
        button.BorderThickness = System.Windows.Thickness(0)
        button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left
        button.Click += click_handler
        
        stack = StackPanel()
        
        title = TextBlock()
        title.Text = title_text
        title.FontSize = 24
        title.FontWeight = System.Windows.FontWeights.SemiBold
        
        subtitle = TextBlock()
        subtitle.Text = subtitle_text
        subtitle.FontSize = 14
        subtitle.Foreground = SolidColorBrush(Colors.Gray)
        subtitle.TextWrapping = System.Windows.TextWrapping.Wrap
        
        stack.Children.Add(title)
        stack.Children.Add(subtitle)
        
        button.Content = stack
        border.Child = button
        
        return border
        
    def create_qr_screen(self) -> ScrollViewer:
        """Create QR code display screen"""
        scroller = ScrollViewer()
        
        container = StackPanel()
        container.Padding = System.Windows.Thickness(40)
        container.Spacing = 20
        
        # Header with mode badge
        header = StackPanel()
        header.Orientation = Controls.Orientation.Horizontal
        header.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        header.Spacing = 10
        
        mode_badge = TextBlock()
        mode_badge.Text = "WiFi Mode"
        mode_badge.FontSize = 16
        mode_badge.Padding = System.Windows.Thickness(15, 5, 15, 5)
        mode_badge.Background = SolidColorBrush(Colors.LightBlue)
        mode_badge.CornerRadius = System.Windows.CornerRadius(15)
        self.mode_badge = mode_badge
        
        license_badge = TextBlock()
        license_badge.Text = "FREE"
        license_badge.FontSize = 16
        license_badge.Padding = System.Windows.Thickness(15, 5, 15, 5)
        license_badge.Foreground = SolidColorBrush(Colors.Orange)
        self.qr_license_badge = license_badge
        
        header.Children.Add(mode_badge)
        header.Children.Add(license_badge)
        
        # Instructions
        instructions_title = TextBlock()
        instructions_title.Text = "WiFi Instructions"
        instructions_title.FontSize = 24
        instructions_title.FontWeight = System.Windows.FontWeights.SemiBold
        instructions_title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        self.instructions_title = instructions_title
        
        instructions_list = StackPanel()
        instructions_list.Spacing = 10
        self.instructions_list = instructions_list
        
        # QR Code container
        qr_container = Border()
        qr_container.Background = SolidColorBrush(Colors.White)
        qr_container.Padding = System.Windows.Thickness(20)
        qr_container.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        qr_container.CornerRadius = System.Windows.CornerRadius(10)
        
        qr_image = Image()
        qr_image.Width = 300
        qr_image.Height = 300
        self.qr_image = qr_image
        qr_container.Child = qr_image
        
        # URL display
        url_text = TextBlock()
        url_text.Text = "http://0.0.0.0:0000"
        url_text.FontSize = 14
        url_text.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        url_text.Foreground = SolidColorBrush(Colors.Gray)
        self.url_text = url_text
        
        # Status message
        status_text = TextBlock()
        status_text.Text = "Waiting for connection..."
        status_text.FontSize = 16
        status_text.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        self.status_text = status_text
        
        # Progress bar
        progress_bar = ProgressBar()
        progress_bar.Visibility = Visibility.Collapsed
        progress_bar.Width = 400
        self.progress_bar = progress_bar
        
        progress_label = TextBlock()
        progress_label.Text = ""
        progress_label.FontSize = 14
        progress_label.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        progress_label.Visibility = Visibility.Collapsed
        self.progress_label = progress_label
        
        # Stats
        stats_text = TextBlock()
        stats_text.Text = "Transfers today: 0"
        stats_text.FontSize = 14
        stats_text.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        stats_text.Foreground = SolidColorBrush(Colors.Gray)
        self.stats_text = stats_text
        
        # Upload path
        upload_path = TextBlock()
        upload_path.Text = f"Files saved to: {self.config.get_upload_folder()}"
        upload_path.FontSize = 12
        upload_path.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        upload_path.Foreground = SolidColorBrush(Colors.Gray)
        upload_path.TextWrapping = System.Windows.TextWrapping.Wrap
        self.upload_path = upload_path
        
        # Action buttons
        actions = StackPanel()
        actions.Orientation = Controls.Orientation.Horizontal
        actions.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        actions.Spacing = 15
        
        change_network_btn = Button()
        change_network_btn.Content = "Change Network"
        change_network_btn.Click += self.on_change_network_click
        
        view_files_btn = Button()
        view_files_btn.Content = "View Files"
        view_files_btn.Click += self.on_view_files_click
        
        settings_btn = Button()
        settings_btn.Content = "Settings"
        settings_btn.Click += self.on_settings_click
        
        actions.Children.Add(change_network_btn)
        actions.Children.Add(view_files_btn)
        actions.Children.Add(settings_btn)
        
        # Back button
        back_btn = Button()
        back_btn.Content = "← Back"
        back_btn.Click += self.on_qr_back_click
        back_btn.HorizontalAlignment = System.Windows.HorizontalAlignment.Center
        
        # Add all elements
        container.Children.Add(header)
        container.Children.Add(instructions_title)
        container.Children.Add(instructions_list)
        container.Children.Add(qr_container)
        container.Children.Add(url_text)
        container.Children.Add(status_text)
        container.Children.Add(progress_bar)
        container.Children.Add(progress_label)
        container.Children.Add(stats_text)
        container.Children.Add(upload_path)
        container.Children.Add(actions)
        container.Children.Add(back_btn)
        
        scroller.Content = container
        return scroller
        
    # Event Handlers
    def on_get_started_click(self, sender, e):
        """Handle Get Started button click"""
        self.show_screen("mode")
        
    def on_mode_selected(self, mode: str):
        """Handle mode selection"""
        self.network_mode = mode
        self.show_qr_screen()
        
    def on_qr_back_click(self, sender, e):
        """Handle back button on QR screen"""
        self.stop_server()
        self.show_screen("mode")
        
    def on_change_network_click(self, sender, e):
        """Handle change network button"""
        self.stop_server()
        self.network_mode = None
        self.show_screen("mode")
        
    def on_view_files_click(self, sender, e):
        """Open uploaded files folder"""
        upload_dir = self.config.get_upload_folder()
        if os.path.exists(upload_dir):
            os.startfile(upload_dir)
        else:
            self.set_status("No files uploaded yet")
            
    def on_settings_click(self, sender, e):
        """Open settings dialog"""
        # TODO: Implement WinUI 3 settings dialog
        pass
        
    # Screen Management
    def show_screen(self, screen_name: str):
        """Show specific screen and hide others"""
        self.current_screen = screen_name
        
        self.welcome_screen.Visibility = Visibility.Visible if screen_name == "welcome" else Visibility.Collapsed
        self.mode_screen.Visibility = Visibility.Visible if screen_name == "mode" else Visibility.Collapsed
        self.qr_screen.Visibility = Visibility.Visible if screen_name == "qr" else Visibility.Collapsed
        
    def show_qr_screen(self):
        """Display QR screen and start server"""
        if not self.network_mode:
            return
            
        self.show_screen("qr")
        
        # Update mode badge
        mode_text = "Hotspot Mode" if self.network_mode == "hotspot" else "WiFi Mode"
        self.mode_badge.Text = mode_text
        
        # Update license badge
        license_text = "PRO" if self.license_manager.is_pro() else "FREE"
        self.qr_license_badge.Text = license_text
        
        # Update instructions
        if self.network_mode == "hotspot":
            self.instructions_title.Text = "Hotspot Instructions"
            steps = [
                "1. Enable Mobile Hotspot on your phone",
                "2. Connect this PC to that hotspot",
                "3. Keep this screen open and scan the QR code"
            ]
        else:
            self.instructions_title.Text = "WiFi Instructions"
            steps = [
                "1. Connect phone and PC to the same WiFi",
                "2. Leave this screen open",
                "3. Scan the QR code with your phone camera"
            ]
            
        self.instructions_list.Children.Clear()
        for step in steps:
            step_text = TextBlock()
            step_text.Text = step
            step_text.FontSize = 16
            self.instructions_list.Children.Add(step_text)
        
        # Start server
        self.start_server()
        
    # Server Management
    def start_server(self):
        """Start the transfer server and display QR code"""
        self.stop_server()
        
        local_ip = self.get_local_ip()
        port = self.config.get_port()
        
        if not local_ip:
            self.set_status("No network connection - connect to WiFi or Hotspot")
            return
            
        url = f"http://{local_ip}:{port}"
        self.display_qr_code(url)
        self.url_text.Text = url
        
        # Setup server callbacks
        callbacks = {
            'status_update': self.on_status_update,
            'transfer_complete': self.on_transfer_complete,
            'upload_progress': self.on_upload_progress,
            'client_connected': self.on_client_connected
        }
        
        self.server_thread = ServerThread(port=port, callbacks=callbacks)
        self.server_thread.start()
        
        mode_name = "Hotspot" if self.network_mode == "hotspot" else "WiFi"
        self.set_status(f"Server running on {mode_name} - Waiting for connections...")
        
    def stop_server(self):
        """Stop the transfer server"""
        if self.server_thread:
            if hasattr(self.server_thread, 'server') and self.server_thread.server:
                # Terminate server gracefully
                pass
            self.server_thread = None
            
        # Hide progress
        self.progress_bar.Visibility = Visibility.Collapsed
        self.progress_label.Visibility = Visibility.Collapsed
        
    def get_local_ip(self) -> Optional[str]:
        """Get local IP address"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            return ip
        except OSError:
            return None
            
    def display_qr_code(self, url: str):
        """Generate and display QR code"""
        try:
            qr = self.qr_generator.generate(url)
            
            # Save QR code to temporary file
            temp_path = Path.home() / ".airbamin" / "temp_qr.png"
            temp_path.parent.mkdir(parents=True, exist_ok=True)
            qr.save(str(temp_path), format="PNG")
            
            # Load into WinUI Image control
            bitmap = BitmapImage()
            bitmap.UriSource = Uri(str(temp_path.absolute()))
            self.qr_image.Source = bitmap
            
        except Exception as exc:
            self.set_status(f"QR Error: {exc}")
            
    # Server Callbacks (called from background thread)
    def on_status_update(self, message: str):
        """Handle status update from server"""
        # Marshal to UI thread
        self.DispatcherQueue.TryEnqueue(lambda: self.set_status(message))
        
    def on_transfer_complete(self, filename: str, file_size: int):
        """Handle transfer completion"""
        def update_ui():
            self.progress_bar.Visibility = Visibility.Collapsed
            self.progress_label.Visibility = Visibility.Collapsed
            
            size_mb = file_size / (1024 * 1024)
            self.set_status(f"Received: {filename} ({size_mb:.1f} MB)")
            
            stats = self.config.get_daily_stats()
            self.stats_text.Text = f"Transfers today: {stats['count']}"
            
        self.DispatcherQueue.TryEnqueue(update_ui)
        
    def on_upload_progress(self, filename: str, bytes_received: int, total_bytes: int):
        """Handle upload progress update"""
        if total_bytes <= 0:
            return
            
        def update_ui():
            percent = int((bytes_received / total_bytes) * 100)
            self.progress_bar.Value = percent
            self.progress_bar.Visibility = Visibility.Visible
            
            label = f"Uploading {filename}: {bytes_received / (1024 * 1024):.1f} MB / {total_bytes / (1024 * 1024):.1f} MB"
            self.progress_label.Text = label
            self.progress_label.Visibility = Visibility.Visible
            
        self.DispatcherQueue.TryEnqueue(update_ui)
        
    def on_client_connected(self, ip: str):
        """Handle client connection"""
        self.DispatcherQueue.TryEnqueue(lambda: self.set_status(f"Phone connected from {ip}"))
        
    # UI Helper Methods
    def set_status(self, message: str):
        """Update status message"""
        self.status_text.Text = message


class AirBaminApp(Application):
    """WinUI 3 Application"""
    
    def __init__(self):
        super().__init__()
        self.window = None
        
    def OnLaunched(self, args):
        """Application launch handler"""
        self.window = AirBaminWindow()
        self.window.Activate()


def run_app():
    """Entry point for WinUI 3 application"""
    if not WINUI_AVAILABLE:
        print("ERROR: WinUI 3 is not available!")
        print("Please install Windows App SDK:")
        print("  1. Install .NET 6+ SDK")
        print("  2. Install Windows App SDK: https://learn.microsoft.com/windows/apps/windows-app-sdk/")
        print("  3. Or use PyQt6 native widgets fallback")
        return
        
    app = AirBaminApp()
    Application.Start(lambda: app)
