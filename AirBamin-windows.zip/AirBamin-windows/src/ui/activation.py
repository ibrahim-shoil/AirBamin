"""
License Activation Dialog
Enter and validate Pro license key
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QLineEdit, QMessageBox, QTextEdit)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class ActivationDialog(QDialog):
    """License activation dialog"""
    
    def __init__(self, license_manager, parent=None):
        super().__init__(parent)
        self.license_manager = license_manager
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        self.setWindowTitle("Activate AirBamin Pro")
        self.setMinimumSize(500, 550)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # Header
        title = QLabel("⭐ Upgrade to Pro")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #16a34a;")
        layout.addWidget(title)
        
        # Features
        features = QTextEdit()
        features.setReadOnly(True)
        features.setMaximumHeight(180)
        features.setStyleSheet("""
            QTextEdit {
                background-color: #f0fdf4;
                border: 2px solid #16a34a;
                border-radius: 10px;
                padding: 15px;
                font-size: 13px;
            }
        """)
        features.setHtml("""
            <h3 style="color: #16a34a; margin-top: 0;">Pro Features:</h3>
            <ul style="margin: 10px 0;">
                <li><b>Unlimited transfers</b> - No daily limits</li>
                <li><b>Unlimited file size</b> - Transfer files of any size</li>
                <li><b>Faster speeds</b> - Optimized performance</li>
                <li><b>Custom save locations</b> - Choose where files go</li>
                <li><b>Transfer history</b> - Track all your transfers</li>
                <li><b>Lifetime updates</b> - Never pay again</li>
            </ul>
        """)
        layout.addWidget(features)
        
        # Price
        price_label = QLabel("$29.99 - One-time payment")
        price_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        price_label.setStyleSheet("""
            font-size: 18px;
            font-weight: bold;
            color: #16a34a;
            background-color: #f0fdf4;
            padding: 12px;
            border-radius: 8px;
        """)
        layout.addWidget(price_label)
        
        # Purchase button
        purchase_btn = QPushButton("🛒 Purchase License Key")
        purchase_btn.clicked.connect(self.open_purchase_page)
        purchase_btn.setStyleSheet("""
            QPushButton {
                background-color: #16a34a;
                color: white;
                padding: 12px;
                border-radius: 8px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #15803d;
            }
        """)
        layout.addWidget(purchase_btn)
        
        # Separator
        separator = QLabel("Already purchased? Enter your license key:")
        separator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        separator.setStyleSheet("color: #666; margin-top: 10px;")
        layout.addWidget(separator)
        
        # License key input
        key_label = QLabel("License Key:")
        key_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(key_label)
        
        self.key_input = QLineEdit()
        self.key_input.setPlaceholderText("AIRBM-XXXXX-XXXXX-XXXXX-XXXXX")
        self.key_input.setStyleSheet("""
            QLineEdit {
                padding: 10px;
                font-size: 14px;
                font-family: monospace;
                border: 2px solid #ddd;
                border-radius: 6px;
            }
            QLineEdit:focus {
                border-color: #16a34a;
            }
        """)
        self.key_input.textChanged.connect(self.format_license_key)
        layout.addWidget(self.key_input)
        
        # Activate button
        activate_btn = QPushButton("✅ Activate License")
        activate_btn.clicked.connect(self.activate_license)
        activate_btn.setStyleSheet("""
            QPushButton {
                background-color: #2563eb;
                color: white;
                padding: 12px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
        """)
        layout.addWidget(activate_btn)
        
        layout.addStretch()
        
        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        close_btn.setStyleSheet("padding: 8px;")
        layout.addWidget(close_btn)
        
    def format_license_key(self, text):
        """Auto-format license key as user types"""
        # Remove all non-alphanumeric characters
        text = ''.join(c for c in text.upper() if c.isalnum())
        
        # Add hyphens
        if len(text) > 5:
            text = text[:5] + '-' + text[5:]
        if len(text) > 11:
            text = text[:11] + '-' + text[11:]
        if len(text) > 17:
            text = text[:17] + '-' + text[17:]
        if len(text) > 23:
            text = text[:23] + '-' + text[23:]
        
        # Limit to proper length
        text = text[:29]
        
        # Update input without triggering this function again
        cursor_pos = self.key_input.cursorPosition()
        self.key_input.blockSignals(True)
        self.key_input.setText(text)
        self.key_input.setCursorPosition(min(cursor_pos, len(text)))
        self.key_input.blockSignals(False)
        
    def open_purchase_page(self):
        """Open purchase page in browser"""
        import webbrowser
        
        # Replace with your actual Gumroad link
        purchase_url = "https://gumroad.com/l/airbamin-pro"
        
        # For now, show placeholder
        QMessageBox.information(
            self,
            "Purchase AirBamin Pro",
            f"Purchase page will open in your browser.\n\n"
            f"After purchase, you'll receive a license key via email.\n"
            f"Enter it here to activate Pro features.\n\n"
            f"URL: {purchase_url}"
        )
        
        # Uncomment to actually open browser:
        # webbrowser.open(purchase_url)
        
    def activate_license(self):
        """Activate the entered license key"""
        license_key = self.key_input.text().strip()
        
        if not license_key:
            QMessageBox.warning(self, "Error", "Please enter a license key")
            return
            
        # Validate and activate
        success, message = self.license_manager.activate_license(license_key)
        
        if success:
            QMessageBox.information(
                self,
                "Success!",
                "🎉 License activated successfully!\n\n"
                "You now have access to all Pro features:\n"
                "• Unlimited transfers\n"
                "• Unlimited file sizes\n"
                "• And more!\n\n"
                "Enjoy AirBamin Pro!"
            )
            self.accept()
        else:
            QMessageBox.critical(
                self,
                "Activation Failed",
                f"Could not activate license:\n\n{message}\n\n"
                "Please check your license key and try again.\n"
                "Contact support if the problem persists."
            )
