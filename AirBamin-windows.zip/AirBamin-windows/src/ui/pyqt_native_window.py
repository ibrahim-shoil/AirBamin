"""
AirBamin Main Window - PyQt6 Native Widgets (No WebEngine)
Pure native Qt widgets for cross-platform compatibility
"""

from __future__ import annotations

import base64
import os
import socket
import threading
from io import BytesIO
from pathlib import Path
from typing import Optional

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget,
    QLabel, QPushButton, QProgressBar, QMessageBox, QFileDialog
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt6.QtGui import QPixmap, QFont

from core.config import Config
from core.license import LicenseManager
from core.qr_generator import QRGenerator
from core.network_scanner import NetworkScanner
from server.transfer_server import TransferServer


class ServerThread(QThread):
    """Run transfer server in background thread"""
    
    status_update = pyqtSignal(str)
    transfer_complete = pyqtSignal(str, int)
    upload_progress = pyqtSignal(str, int, int)
    client_connected = pyqtSignal(str)

    def __init__(self, port: int = 8080) -> None:
        super().__init__()
        self.port = port
        self.server: Optional[TransferServer] = None

    def run(self) -> None:
        try:
            print(f"[SERVER-THREAD] Creating server on port {self.port}...")
            self.server = TransferServer(port=self.port)
            self.server.on_status_change = self.status_update.emit
            self.server.on_transfer_complete = self.transfer_complete.emit
            self.server.on_upload_progress = self.upload_progress.emit
            self.server.on_client_connected = self.client_connected.emit
            print(f"[SERVER-THREAD] Starting server...")
            self.server.start()
            print(f"[SERVER-THREAD] Server stopped")
        except Exception as exc:
            print(f"[SERVER-THREAD] ❌ ERROR: {exc}")
            import traceback
            traceback.print_exc()
            self.status_update.emit(f"❌ Error: {exc}")


class PyQtNativeWindow(QMainWindow):
    """Main application window with native PyQt6 widgets"""
    
    def __init__(self):
        super().__init__()
        
        self.config = Config()
        self.license_manager = LicenseManager()
        self.qr_generator = QRGenerator()
        self.network_scanner = NetworkScanner()
        self.server_thread: Optional[ServerThread] = None
        self.network_mode: Optional[str] = None
        self.session_files: list = []  # Track files in current session
        self.current_ip: Optional[str] = None  # Track current IP for change detection
        self.network_monitor_timer: Optional[QTimer] = None  # Timer for monitoring network changes
        self.device_scan_timer: Optional[QTimer] = None  # Timer for scanning new devices
        self.notified_devices: set = set()  # Track devices we've already notified about
        
        self.setWindowTitle("AirBamin - Easy File Transfer")
        self.setMinimumSize(550, 750)
        self.resize(600, 800)
        
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize UI"""
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Stacked widget for screens
        self.screens = QStackedWidget()
        layout.addWidget(self.screens)
        
        # Create screens
        self.welcome_screen = self.create_welcome_screen()
        self.mode_screen = self.create_mode_screen()
        self.qr_screen = self.create_qr_screen()
        
        self.screens.addWidget(self.welcome_screen)
        self.screens.addWidget(self.mode_screen)
        self.screens.addWidget(self.qr_screen)
        
        self.show_screen(0)
        
    def create_welcome_screen(self) -> QWidget:
        """Create welcome screen"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Title
        title = QLabel("AirBamin")
        title.setFont(QFont("Arial", 36, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Transfer files from your phone to PC wirelessly")
        subtitle.setFont(QFont("Arial", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #666;")
        layout.addWidget(subtitle)
        
        # Features
        features_widget = QWidget()
        features_layout = QVBoxLayout(features_widget)
        features_layout.setSpacing(15)
        
        features = [
            "📱 Scan QR code from your phone",
            "⚡ Fast wireless transfer",
            "🔒 Secure local network connection",
            "📂 Automatic file organization"
        ]
        
        for feature in features:
            label = QLabel(feature)
            label.setFont(QFont("Arial", 12))
            features_layout.addWidget(label)
        
        layout.addWidget(features_widget)
        
        # Get Started button
        btn = QPushButton("Get Started")
        btn.setFont(QFont("Arial", 14))
        btn.setMinimumHeight(50)
        btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 40px;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)
        btn.clicked.connect(lambda: self.show_screen(1))
        layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # License badge
        self.welcome_license_label = QLabel("FREE" if not self.license_manager.is_pro() else "PRO")
        self.welcome_license_label.setFont(QFont("Arial", 10))
        self.welcome_license_label.setStyleSheet("color: #888;")
        self.welcome_license_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.welcome_license_label)
        
        layout.addStretch()
        
        return widget
        
    def create_mode_screen(self) -> QWidget:
        """Create mode selection screen"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Title
        title = QLabel("Choose Connection Mode")
        title.setFont(QFont("Arial", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        layout.addSpacing(20)
        
        # WiFi Mode button
        wifi_btn = self.create_mode_button(
            "📶 WiFi Mode",
            "Connect when both devices are on the same WiFi network",
            lambda: self.on_mode_selected("wifi")
        )
        layout.addWidget(wifi_btn)
        
        # Hotspot Mode button
        hotspot_btn = self.create_mode_button(
            "📡 Hotspot Mode",
            "Connect PC to phone's mobile hotspot",
            lambda: self.on_mode_selected("hotspot")
        )
        layout.addWidget(hotspot_btn)
        
        layout.addStretch()
        
        # Back button
        back_btn = QPushButton("← Back")
        back_btn.clicked.connect(lambda: self.show_screen(0))
        layout.addWidget(back_btn)
        
        return widget
        
    def create_mode_button(self, title: str, subtitle: str, callback) -> QPushButton:
        """Create styled mode button"""
        btn = QPushButton()
        btn.setMinimumHeight(100)
        btn.setStyleSheet("""
            QPushButton {
                background-color: #f5f5f5;
                border: 2px solid #ddd;
                border-radius: 10px;
                text-align: left;
                padding: 20px;
            }
            QPushButton:hover {
                background-color: #e8e8e8;
                border-color: #0078d4;
            }
        """)
        
        # Create layout for button content
        btn_layout = QVBoxLayout()
        
        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        btn_layout.addWidget(title_label)
        
        subtitle_label = QLabel(subtitle)
        subtitle_label.setFont(QFont("Arial", 11))
        subtitle_label.setStyleSheet("color: #666;")
        subtitle_label.setWordWrap(True)
        btn_layout.addWidget(subtitle_label)
        
        btn.setLayout(btn_layout)
        btn.clicked.connect(callback)
        
        return btn
        
    def create_qr_screen(self) -> QWidget:
        """Create QR code screen"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Header
        header = QHBoxLayout()
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.mode_badge = QLabel("WiFi Mode")
        self.mode_badge.setStyleSheet("""
            background-color: #e3f2fd;
            color: #1976d2;
            padding: 5px 15px;
            border-radius: 15px;
        """)
        header.addWidget(self.mode_badge)
        
        self.license_badge = QLabel("FREE")
        self.license_badge.setStyleSheet("color: #888; padding-left: 10px;")
        header.addWidget(self.license_badge)
        
        layout.addLayout(header)
        
        # Instructions title
        self.instructions_title = QLabel("WiFi Instructions")
        self.instructions_title.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        self.instructions_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.instructions_title)
        
        # Instructions list
        self.instructions_widget = QWidget()
        self.instructions_layout = QVBoxLayout(self.instructions_widget)
        layout.addWidget(self.instructions_widget)
        
        # QR Code
        self.qr_label = QLabel()
        self.qr_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.qr_label.setMinimumSize(300, 300)
        self.qr_label.setStyleSheet("background-color: white; padding: 20px; border-radius: 10px;")
        layout.addWidget(self.qr_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # URL
        self.url_label = QLabel("http://0.0.0.0:0000")
        self.url_label.setFont(QFont("Arial", 10))
        self.url_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.url_label.setStyleSheet("color: #666;")
        layout.addWidget(self.url_label)
        
        # Status
        self.status_label = QLabel("Waiting for connection...")
        self.status_label.setFont(QFont("Arial", 12))
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setWordWrap(True)
        self.status_label.setMinimumHeight(40)
        layout.addWidget(self.status_label)
        
        # Session files list
        session_label = QLabel("Files received this session:")
        session_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        session_label.setStyleSheet("color: #555; margin-top: 10px;")
        layout.addWidget(session_label)
        
        self.session_files_label = QLabel("No files yet")
        self.session_files_label.setFont(QFont("Arial", 9))
        self.session_files_label.setStyleSheet("""
            background-color: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            color: #666;
        """)
        self.session_files_label.setWordWrap(True)
        self.session_files_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.session_files_label.setMaximumHeight(100)
        layout.addWidget(self.session_files_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setMinimumHeight(25)
        layout.addWidget(self.progress_bar)
        
        self.progress_label = QLabel()
        self.progress_label.setFont(QFont("Arial", 10))
        self.progress_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progress_label.setVisible(False)
        layout.addWidget(self.progress_label)
        
        # Stats
        self.stats_label = QLabel("Transfers today: 0")
        self.stats_label.setFont(QFont("Arial", 10))
        self.stats_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.stats_label.setStyleSheet("color: #888;")
        layout.addWidget(self.stats_label)
        
        # Upload path
        self.upload_path_label = QLabel(f"Files saved to: {self.config.get_upload_folder()}")
        self.upload_path_label.setFont(QFont("Arial", 9))
        self.upload_path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.upload_path_label.setStyleSheet("color: #888;")
        self.upload_path_label.setWordWrap(True)
        layout.addWidget(self.upload_path_label)
        
        # Buttons
        buttons = QHBoxLayout()
        buttons.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        refresh_btn = QPushButton("🔄 Refresh Network")
        refresh_btn.setToolTip("Reconnect after switching WiFi/Hotspot")
        refresh_btn.clicked.connect(self.on_refresh_network)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                padding: 8px 15px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)
        buttons.addWidget(refresh_btn)
        
        change_btn = QPushButton("Change Mode")
        change_btn.setToolTip("Switch between WiFi and Hotspot")
        change_btn.clicked.connect(self.on_change_network)
        buttons.addWidget(change_btn)
        
        files_btn = QPushButton("View Files")
        files_btn.clicked.connect(self.on_view_files)
        buttons.addWidget(files_btn)
        
        layout.addLayout(buttons)
        
        # Back button
        back_btn = QPushButton("← Back")
        back_btn.clicked.connect(self.on_qr_back)
        layout.addWidget(back_btn)
        
        return widget
        
    def show_screen(self, index: int):
        """Show screen by index"""
        self.screens.setCurrentIndex(index)
        
    def on_mode_selected(self, mode: str):
        """Handle mode selection"""
        self.network_mode = mode
        self.show_qr_screen()
        
    def show_qr_screen(self):
        """Display QR screen and start server"""
        self.show_screen(2)
        
        # Reset session files when starting new mode
        self.session_files = []
        self.update_session_files_display()
        
        # Update mode badge
        mode_text = "Hotspot Mode" if self.network_mode == "hotspot" else "WiFi Mode"
        self.mode_badge.setText(mode_text)
        
        # Update license
        self.license_badge.setText("PRO" if self.license_manager.is_pro() else "FREE")
        
        # Update instructions
        if self.network_mode == "hotspot":
            self.instructions_title.setText("Hotspot Instructions")
            steps = [
                "1. Enable Mobile Hotspot on your phone",
                "2. Connect this PC to that hotspot",
                "3. Keep this screen open and scan the QR code"
            ]
        else:
            self.instructions_title.setText("WiFi Instructions")
            steps = [
                "1. Connect phone and PC to the same WiFi",
                "2. Leave this screen open",
                "3. Scan the QR code with your phone camera"
            ]
        
        # Clear and add instructions
        while self.instructions_layout.count():
            self.instructions_layout.takeAt(0).widget().deleteLater()
        
        for step in steps:
            label = QLabel(step)
            label.setFont(QFont("Arial", 11))
            self.instructions_layout.addWidget(label)
        
        # Start server
        self.start_server()
        
    def start_server(self):
        """Start transfer server"""
        self.stop_server()
        
        local_ip = self.get_local_ip()
        port = self.config.get_port()
        
        if not local_ip:
            self.status_label.setText("No network connection - Please connect to WiFi or Hotspot first")
            self.status_label.setStyleSheet("color: #d32f2f; font-weight: bold;")
            return
        
        url = f"http://{local_ip}:{port}/upload"
        self.display_qr_code(url)
        self.url_label.setText(url)
        
        self.server_thread = ServerThread(port=port)
        self.server_thread.status_update.connect(self.on_status_update)
        self.server_thread.transfer_complete.connect(self.on_transfer_complete)
        self.server_thread.upload_progress.connect(self.on_upload_progress)
        self.server_thread.client_connected.connect(self.on_client_connected)
        self.server_thread.start()
        
        mode_name = "Hotspot" if self.network_mode == "hotspot" else "WiFi"
        self.status_label.setText(f"Server running on {mode_name} - Waiting for connections...")
        self.status_label.setStyleSheet("color: #388e3c;")
        
        # Store current IP and start monitoring for changes
        self.current_ip = local_ip
        self.start_network_monitoring()
        
    def stop_server(self):
        """Stop transfer server"""
        if self.server_thread and self.server_thread.isRunning():
            self.server_thread.terminate()
            self.server_thread.wait()
        self.server_thread = None
        
        # Stop network monitoring
        self.stop_network_monitoring()
        
        self.progress_bar.setVisible(False)
        self.progress_label.setVisible(False)
        
    def get_local_ip(self) -> Optional[str]:
        """Get local IP address"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            print(f"[NETWORK] Current IP detected: {ip}")
            return ip
        except OSError:
            print("[NETWORK] No network connection detected")
            return None
            
    def display_qr_code(self, url: str):
        """Generate and display QR code"""
        try:
            qr = self.qr_generator.generate(url)
            buffer = BytesIO()
            qr.save(buffer, format="PNG")
            
            pixmap = QPixmap()
            pixmap.loadFromData(buffer.getvalue())
            pixmap = pixmap.scaled(300, 300, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.qr_label.setPixmap(pixmap)
        except Exception as exc:
            self.status_label.setText(f"QR Error: {exc}")
            self.status_label.setStyleSheet("color: #d32f2f;")
    
    def start_network_monitoring(self):
        """Start monitoring for network changes"""
        if self.network_monitor_timer:
            self.network_monitor_timer.stop()
        
        self.network_monitor_timer = QTimer()
        self.network_monitor_timer.timeout.connect(self.check_network_change)
        self.network_monitor_timer.start(3000)  # Check every 3 seconds
        print("[NETWORK] Started monitoring for IP changes")
        
        # Do initial silent scan to populate known devices (don't show notifications)
        print("[NETWORK] Running initial device scan (silent)...")
        self.network_scanner.detect_new_devices()  # This populates known_devices without returning anything
        print("[NETWORK] Initial scan complete - existing devices registered")
        
        # Also start device scanning for future changes
        if self.device_scan_timer:
            self.device_scan_timer.stop()
        
        self.device_scan_timer = QTimer()
        self.device_scan_timer.timeout.connect(self.scan_for_new_devices)
        self.device_scan_timer.start(5000)  # Scan every 5 seconds
        print("[NETWORK] Started scanning for new devices")
    
    def stop_network_monitoring(self):
        """Stop monitoring network changes"""
        if self.network_monitor_timer:
            self.network_monitor_timer.stop()
            self.network_monitor_timer = None
            print("[NETWORK] Stopped monitoring")
        
        if self.device_scan_timer:
            self.device_scan_timer.stop()
            self.device_scan_timer = None
            print("[NETWORK] Stopped device scanning")
    
    def check_network_change(self):
        """Check if IP address has changed"""
        new_ip = self.get_local_ip()
        
        # If IP changed, restart server with new IP
        if new_ip and new_ip != self.current_ip:
            old_ip = self.current_ip if self.current_ip else "None"
            print(f"[NETWORK] ⚠️ IP CHANGED DETECTED!")
            print(f"[NETWORK] Old IP: {old_ip}")
            print(f"[NETWORK] New IP: {new_ip}")
            self.current_ip = new_ip
            
            # Stop current server completely
            if self.server_thread and self.server_thread.isRunning():
                print("[NETWORK] Stopping old server...")
                self.server_thread.terminate()
                self.server_thread.wait()
                self.server_thread = None
            
            # Update QR code and URL
            port = self.config.get_port()
            url = f"http://{new_ip}:{port}/upload"
            self.display_qr_code(url)
            self.url_label.setText(url)
            
            # Show notification
            self.status_label.setText(f"🔄 Network changed! New IP: {new_ip} - Scan the updated QR code")
            self.status_label.setStyleSheet("color: #ff9800; font-weight: bold;")
            
            # Restart server with new IP
            print(f"[NETWORK] Starting new server on {new_ip}:{port}")
            self.server_thread = ServerThread(port=port)
            self.server_thread.status_update.connect(self.on_status_update)
            self.server_thread.transfer_complete.connect(self.on_transfer_complete)
            self.server_thread.upload_progress.connect(self.on_upload_progress)
            self.server_thread.client_connected.connect(self.on_client_connected)
            self.server_thread.start()
            
            print("[NETWORK] ✅ Server restarted with new IP!")
    
    def scan_for_new_devices(self):
        """Scan for newly connected devices on the network"""
        try:
            new_devices = self.network_scanner.detect_new_devices()
            
            if new_devices:
                for device in new_devices:
                    ip = device['ip']
                    
                    # Only notify if we haven't notified about this device yet
                    if ip not in self.notified_devices:
                        print(f"[NETWORK] 📱 New device detected: {ip}")
                        self.notified_devices.add(ip)
                        
                        # Show notification
                        self.status_label.setText(f"📱 New device joined network: {ip} - Ready to scan QR!")
                        self.status_label.setStyleSheet("color: #10b981; font-weight: bold;")
                        
                        # Reset after 5 seconds
                        QTimer.singleShot(5000, lambda: self.reset_status_if_waiting())
        except Exception as e:
            print(f"[NETWORK] Device scan error: {e}")
    
    def reset_status_if_waiting(self):
        """Reset status to waiting if no upload is active"""
        if hasattr(self, 'server_thread') and self.server_thread and self.server_thread.isRunning():
            mode_name = "Hotspot" if self.network_mode == "hotspot" else "WiFi"
            self.status_label.setText(f"Server running on {mode_name} - Waiting for connections...")
            self.status_label.setStyleSheet("color: #388e3c;")
    
    def on_client_connected(self, client_ip: str):
        """Handle client connection"""
        self.status_label.setText(f"📱 Phone connected from {client_ip} - Upload starting...")
        self.status_label.setStyleSheet("color: #2196f3; font-weight: bold;")
            
    def on_status_update(self, message: str):
        """Handle status update"""
        self.status_label.setText(message)
        
    def on_transfer_complete(self, filename: str, file_size: int):
        """Handle transfer completion"""
        self.progress_bar.setVisible(False)
        self.progress_label.setVisible(False)
        
        # Add to session files
        size_mb = file_size / (1024 * 1024)
        self.session_files.append(f"{filename} ({size_mb:.1f} MB)")
        self.update_session_files_display()
        
        self.status_label.setText(f"✓ Successfully received: {filename} ({size_mb:.1f} MB)")
        self.status_label.setStyleSheet("color: #388e3c; font-weight: bold;")
        
        stats = self.config.get_daily_stats()
        self.stats_label.setText(f"Transfers today: {stats['count']}")
        
    def on_upload_progress(self, filename: str, bytes_received: int, total_bytes: int):
        """Handle upload progress"""
        if total_bytes <= 0:
            return
        
        percent = int((bytes_received / total_bytes) * 100)
        self.progress_bar.setValue(percent)
        self.progress_bar.setVisible(True)
        
        label = f"Uploading {filename}: {bytes_received / (1024 * 1024):.1f} MB / {total_bytes / (1024 * 1024):.1f} MB"
        self.progress_label.setText(label)
        self.progress_label.setVisible(True)
    
    def reset_session_state(self):
        """Reset session state (called when changing modes)"""
        if self.server_thread and hasattr(self.server_thread, 'server') and self.server_thread.server:
            self.server_thread.server.reset_session()
            print("[SESSION] Session state reset via UI")
        
        # Clear notified devices so we can detect them again
        self.notified_devices.clear()
        print("[SESSION] Cleared device notification history")
    
    def update_session_files_display(self):
        """Update the session files list display"""
        if not self.session_files:
            self.session_files_label.setText("No files received yet")
            self.session_files_label.setStyleSheet("""
                background-color: #f5f5f5;
                padding: 10px;
                border-radius: 5px;
                color: #999;
            """)
        else:
            files_text = "\n".join([f"• {f}" for f in self.session_files[-5:]])  # Show last 5
            if len(self.session_files) > 5:
                files_text = f"...and {len(self.session_files) - 5} more\n" + files_text
            self.session_files_label.setText(files_text)
            self.session_files_label.setStyleSheet("""
                background-color: #e8f5e9;
                padding: 10px;
                border-radius: 5px;
                color: #2e7d32;
                border-left: 3px solid #4caf50;
            """)
        
    def on_refresh_network(self):
        """Refresh network connection and regenerate QR code"""
        self.status_label.setText("Refreshing network connection...")
        self.status_label.setStyleSheet("color: #0078d4;")
        
        # Stop current server
        self.stop_server()
        
        # Wait a moment for network to stabilize
        QTimer.singleShot(500, self.restart_server_with_new_ip)
        
    def restart_server_with_new_ip(self):
        """Restart server with new IP after network change"""
        local_ip = self.get_local_ip()
        
        if not local_ip:
            self.status_label.setText("⚠️ No network detected! Connect to WiFi or Hotspot first")
            self.status_label.setStyleSheet("color: #d32f2f;")
            
            # Show instructions
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setWindowTitle("Network Connection Required")
            
            if self.network_mode == "hotspot":
                msg.setText("Hotspot Mode Instructions:")
                msg.setInformativeText(
                    "1. Enable Mobile Hotspot on your iPhone\n"
                    "2. On this PC, go to WiFi settings\n"
                    "3. Disconnect from current WiFi\n"
                    "4. Connect to your iPhone's hotspot\n"
                    "5. Click 'Refresh Network' button again"
                )
            else:
                msg.setText("WiFi Mode Instructions:")
                msg.setInformativeText(
                    "1. Make sure your PC is connected to WiFi\n"
                    "2. Ensure phone and PC are on the same network\n"
                    "3. Click 'Refresh Network' button again"
                )
            
            msg.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg.exec()
            return
        
        # Restart server with new IP
        port = self.config.get_port()
        url = f"http://{local_ip}:{port}/upload"
        
        self.display_qr_code(url)
        self.url_label.setText(url)
        
        self.server_thread = ServerThread(port=port)
        self.server_thread.status_update.connect(self.on_status_update)
        self.server_thread.transfer_complete.connect(self.on_transfer_complete)
        self.server_thread.upload_progress.connect(self.on_upload_progress)
        self.server_thread.client_connected.connect(self.on_client_connected)
        self.server_thread.start()
        
        mode_name = "Hotspot" if self.network_mode == "hotspot" else "WiFi"
        self.status_label.setText(f"🔄 Network refreshed! Server running on {mode_name} - Waiting for connections...")
        self.status_label.setStyleSheet("color: #0078d4;")
    
    def on_change_network(self):
        """Handle change network mode button"""
        self.stop_server()
        self.network_mode = None
        self.show_screen(1)
        
    def on_view_files(self):
        """Open uploaded files folder"""
        upload_dir = self.config.get_upload_folder()
        if os.path.exists(upload_dir):
            os.startfile(upload_dir)
        else:
            QMessageBox.information(self, "No Files", "No files uploaded yet")
            
    def on_qr_back(self):
        """Handle back button on QR screen"""
        self.stop_server()
        self.show_screen(1)
        
    def closeEvent(self, event):
        """Handle window close"""
        self.stop_server()
        super().closeEvent(event)


def run_pyqt_app():
    """Entry point for PyQt6 native app"""
    from PyQt6.QtWidgets import QApplication
    import sys
    
    app = QApplication(sys.argv)
    window = PyQtNativeWindow()
    window.show()
    sys.exit(app.exec())
