"""
AirBamin Main Window rendered with HTML/CSS inside QWebEngineView.
Manages screen navigation, QR display, and transfer status updates.
"""

from __future__ import annotations

import base64
import json
import os
import socket
from io import BytesIO
from pathlib import Path
from typing import List, Optional, Tuple

from PyQt6.QtCore import QThread, pyqtSignal, QTimer, QUrl
from PyQt6.QtGui import QIcon, QAction
from PyQt6.QtWebEngineCore import QWebEnginePage
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QMainWindow, QSystemTrayIcon, QMenu

from core.config import Config
from core.license import LicenseManager
from core.qr_generator import QRGenerator
from server.transfer_server import TransferServer
from ui.activation import ActivationDialog
from ui.settings import SettingsDialog


class ServerThread(QThread):
    """Run transfer server in background thread"""

    status_update = pyqtSignal(str)
    transfer_complete = pyqtSignal(str, int)
    upload_progress = pyqtSignal(str, int, int)  # filename, bytes_received, total_bytes
    client_connected = pyqtSignal(str)  # client IP

    def __init__(self, port: int = 8080) -> None:
        super().__init__()
        self.port = port
        self.server: Optional[TransferServer] = None

    def run(self) -> None:
        """Start the transfer server"""
        try:
            self.server = TransferServer(port=self.port)
            self.server.on_status_change = self.status_update.emit
            self.server.on_transfer_complete = self.transfer_complete.emit
            self.server.on_upload_progress = self.upload_progress.emit
            self.server.on_client_connected = self.client_connected.emit
            self.server.start()
        except Exception as exc:  # pragma: no cover - reported to UI
            self.status_update.emit(f"❌ Error: {exc}")


class ActionWebPage(QWebEnginePage):
    """Intercept custom action: URLs and relay them to Python"""

    actionTriggered = pyqtSignal(str)

    def acceptNavigationRequest(self, url: QUrl, _type, isMainFrame: bool) -> bool:  # type: ignore[override]
        if url.scheme() == "action":
            action = url.path().lstrip("/") or url.host()
            if action:
                self.actionTriggered.emit(action)
            return False
        return super().acceptNavigationRequest(url, _type, isMainFrame)


class MainWindow(QMainWindow):
    """Main application window rendered via HTML"""

    def __init__(self) -> None:
        super().__init__()

        self.config = Config()
        self.license_manager = LicenseManager()
        self.qr_generator = QRGenerator()
        self.server_thread: Optional[ServerThread] = None
        self.network_mode: Optional[str] = None

        # HTML/JS state snapshots for rehydration on reloads
        self.current_screen = "welcome"
        self.latest_status: Tuple[str, str] = ("Welcome to AirBamin", "info")
        self.latest_stats_text = "Transfers today: 0"
        self.latest_progress: Optional[Tuple[int, str]] = None
        self.latest_qr_data_url: Optional[str] = None
        self.latest_qr_url: str = "http://0.0.0.0:0000"
        self.latest_instructions: Tuple[str, List[str]] = ("WiFi Instructions", [])

        self.page_loaded = False
        self.js_queue: List[str] = []

        self.init_ui()
        self.setup_system_tray()

    # ------------------------------------------------------------------
    # UI bootstrap
    # ------------------------------------------------------------------
    def init_ui(self) -> None:
        self.setWindowTitle("AirBamin - Easy File Transfer")
        self.setMinimumSize(400, 650)
        self.showMaximized()

        self.web_view = QWebEngineView(self)
        self.web_page = ActionWebPage(self.web_view)
        self.web_page.actionTriggered.connect(self.handle_action)
        self.web_view.setPage(self.web_page)
        self.setCentralWidget(self.web_view)
        self.web_view.loadFinished.connect(self.on_html_loaded)

        self.load_html_template()

    def load_html_template(self) -> None:
        template_path = Path(__file__).parent / "templates" / "main_ui.html"
        html = template_path.read_text(encoding="utf-8")
        base_url = QUrl.fromLocalFile(str(template_path.parent.resolve()) + os.sep)
        self.page_loaded = False
        self.web_view.setHtml(html, base_url)

    def on_html_loaded(self, success: bool) -> None:
        if not success:
            return
        self.page_loaded = True
        self.flush_js_queue()
        self.rehydrate_dom()

    # ------------------------------------------------------------------
    # Screen rendering helpers
    # ------------------------------------------------------------------
    def set_screen(self, name: str) -> None:
        self.current_screen = name
        self.run_js(f"setScreen({json.dumps(name)})")

    def show_welcome_screen(self) -> None:
        self.set_screen("welcome")

    def show_mode_screen(self) -> None:
        self.set_screen("mode")

    def on_mode_selected(self, mode: str) -> None:
        self.network_mode = mode
        self.reset_session_state()
        self.show_qr_screen()

    def show_qr_screen(self) -> None:
        if not self.network_mode:
            return
        self.set_screen("qr")
        mode_badge = "Hotspot Mode" if self.network_mode == "hotspot" else "WiFi Mode"
        self.run_js(f"setModeBadge({json.dumps(mode_badge)})")
        self.refresh_license_badge()
        self.update_upload_path()

        if self.network_mode == "hotspot":
            title = "Hotspot Instructions"
            steps = [
                "Enable Mobile Hotspot on your phone",
                "Connect this PC to that hotspot",
                "Keep this screen open and scan the QR code",
            ]
        else:
            title = "WiFi Instructions"
            steps = [
                "Connect phone and PC to the same WiFi",
                "Leave this screen open",
                "Scan the QR code with your phone camera",
            ]
        self.set_instructions(title, steps)
        self.start_server()

    # ------------------------------------------------------------------
    # HTML/JS bridge helpers
    # ------------------------------------------------------------------
    def run_js(self, script: str) -> None:
        if self.page_loaded:
            self.web_view.page().runJavaScript(script)
        else:
            self.js_queue.append(script)

    def flush_js_queue(self) -> None:
        while self.js_queue:
            script = self.js_queue.pop(0)
            self.web_view.page().runJavaScript(script)

    def set_instructions(self, title: str, steps: List[str]) -> None:
        self.latest_instructions = (title, steps)
        self.run_js(f"setInstructions({json.dumps(title)}, {json.dumps(steps)})")

    def set_qr_image(self, data_url: str) -> None:
        self.latest_qr_data_url = data_url
        self.run_js(f"setQrImage({json.dumps(data_url)})")

    def set_qr_url(self, url: str) -> None:
        self.latest_qr_url = url
        self.run_js(f"setQrUrl({json.dumps(url)})")

    def set_status(self, message: str, variant: str = "info") -> None:
        self.latest_status = (message, variant)
        self.run_js(f"setStatus({json.dumps(message)}, {json.dumps(variant)})")

    def set_progress(self, percent: Optional[int], label: str = "") -> None:
        if percent is None:
            self.latest_progress = None
            self.run_js("setProgress(null, '')")
        else:
            self.latest_progress = (percent, label)
            self.run_js(f"setProgress({percent}, {json.dumps(label)})")

    def set_stats(self, text: str) -> None:
        self.latest_stats_text = text
        self.run_js(f"setStats({json.dumps(text)})")

    def update_upload_path(self) -> None:
        upload_path = f"Files will be saved to: {self.config.get_upload_folder()}"
        self.run_js(f"setUploadPath({json.dumps(upload_path)})")

    def refresh_license_badge(self) -> None:
        badge = "PRO" if self.license_manager.is_pro() else "FREE"
        self.run_js(f"setLicenseBadge({json.dumps(badge)})")

    def rehydrate_dom(self) -> None:
        self.set_screen(self.current_screen)
        self.refresh_license_badge()
        self.update_upload_path()
        title, steps = self.latest_instructions
        self.set_instructions(title, steps)
        self.set_qr_url(self.latest_qr_url)
        if self.latest_qr_data_url:
            self.set_qr_image(self.latest_qr_data_url)
        message, variant = self.latest_status
        self.set_status(message, variant)
        if self.latest_progress:
            percent, label = self.latest_progress
            self.set_progress(percent, label)
        else:
            self.set_progress(None)
        self.set_stats(self.latest_stats_text)

    # ------------------------------------------------------------------
    # Action handling
    # ------------------------------------------------------------------
    def handle_action(self, action: str) -> None:
        handlers = {
            "get_started": self.show_mode_screen,
            "mode_back": self.show_welcome_screen,
            "select_mode_wifi": lambda: self.on_mode_selected("wifi"),
            "select_mode_hotspot": lambda: self.on_mode_selected("hotspot"),
            "qr_back": self.handle_qr_back,
            "view_files": self.show_uploaded_files,
            "change_network": self.handle_change_network,
            "open_settings": self.show_settings,
            "upgrade": self.show_activation,
            "cancel_upload": self.cancel_current_upload,
        }
        handler = handlers.get(action)
        if handler:
            handler()

    def handle_qr_back(self) -> None:
        self.stop_server()
        self.reset_session_state()
        self.show_mode_screen()

    def handle_change_network(self) -> None:
        self.stop_server()
        self.reset_session_state()
        self.network_mode = None
        self.show_mode_screen()
        
    def reset_session_state(self) -> None:
        """Reset all session state when changing modes"""
        self.latest_status = ("Ready to connect", "info")
        self.latest_progress = None
        self.latest_qr_data_url = None
        self.latest_qr_url = "http://0.0.0.0:0000"
        self.set_status("Mode changed - Ready for new connection", "info")
        self.set_progress(None)
        
    def cancel_current_upload(self) -> None:
        """Cancel the current upload in progress"""
        import requests
        try:
            local_ip = self.get_local_ip()
            port = self.config.get_port()
            if local_ip:
                url = f"http://{local_ip}:{port}/api/cancel-upload"
                requests.post(url, timeout=1)
                self.set_status("Upload cancelled", "info")
                self.set_progress(None)
        except Exception as exc:
            self.set_status(f"Could not cancel: {exc}", "error")

    # ------------------------------------------------------------------
    # Server + QR generation
    # ------------------------------------------------------------------
    def start_server(self) -> None:
        self.stop_server()
        local_ip = self.get_local_ip()
        port = self.config.get_port()

        if not local_ip:
            self.set_status("No network connection - connect to WiFi or Hotspot", "error")
            return

        url = f"http://{local_ip}:{port}"
        self.display_qr_code(url)
        self.set_qr_url(url)

        self.server_thread = ServerThread(port=port)
        self.server_thread.status_update.connect(lambda msg: self.set_status(msg, "info"))
        self.server_thread.transfer_complete.connect(self.on_transfer_complete)
        self.server_thread.upload_progress.connect(self.on_upload_progress)
        self.server_thread.client_connected.connect(lambda ip: self.set_status(f"Phone connected from {ip}", "info"))
        self.server_thread.start()

        mode_name = "Hotspot" if self.network_mode == "hotspot" else "WiFi"
        self.set_status(f"Server running on {mode_name} - Waiting for connections...", "success")

    def stop_server(self) -> None:
        if self.server_thread and self.server_thread.isRunning():
            self.server_thread.terminate()
            self.server_thread.wait()
        self.server_thread = None
        self.set_progress(None)

    def get_local_ip(self) -> Optional[str]:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            return ip
        except OSError:
            return None

    def display_qr_code(self, url: str) -> None:
        try:
            qr = self.qr_generator.generate(url)
            buffer = BytesIO()
            qr.save(buffer, format="PNG")
            data_url = f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode('ascii')}"
            self.set_qr_image(data_url)
        except Exception as exc:  # pragma: no cover - reported to UI
            self.set_status(f"QR Error: {exc}", "error")

    # ------------------------------------------------------------------
    # Status + progress callbacks
    # ------------------------------------------------------------------
    def on_upload_progress(self, filename: str, bytes_received: int, total_bytes: int) -> None:
        if total_bytes <= 0:
            return
        percent = int((bytes_received / total_bytes) * 100)
        label = f"Uploading {filename}: {bytes_received / (1024 * 1024):.1f} MB / {total_bytes / (1024 * 1024):.1f} MB"
        self.set_progress(percent, label)

    def on_transfer_complete(self, filename: str, file_size: int) -> None:
        self.set_progress(None)
        size_mb = file_size / (1024 * 1024)
        self.set_status(f"Received: {filename} ({size_mb:.1f} MB)", "success")
        stats = self.config.get_daily_stats()
        stats_text = f"Transfers today: {stats['count']}"
        self.set_stats(stats_text)
        QTimer.singleShot(5000, lambda: self.set_status("Ready for transfers", "success"))

    # ------------------------------------------------------------------
    # Dialog actions
    # ------------------------------------------------------------------
    def show_settings(self) -> None:
        dialog = SettingsDialog(self.config, self)
        dialog.showMaximized()
        if dialog.exec():
            self.update_upload_path()

    def show_activation(self) -> None:
        dialog = ActivationDialog(self.license_manager, self)
        dialog.showMaximized()
        if dialog.exec():
            self.refresh_license_badge()

    def show_uploaded_files(self) -> None:
        upload_dir = self.config.get_upload_folder()
        if os.path.exists(upload_dir):
            os.startfile(upload_dir)
        else:
            self.set_status("No files uploaded yet", "info")

    # ------------------------------------------------------------------
    # System tray + lifecycle
    # ------------------------------------------------------------------
    def setup_system_tray(self) -> None:
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        tray_icon = QSystemTrayIcon(QIcon("resources/icon.ico"), self)
        menu = QMenu()
        show_action = QAction("Show AirBamin", self)
        show_action.triggered.connect(self.show)
        menu.addAction(show_action)
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        menu.addAction(quit_action)
        tray_icon.setContextMenu(menu)
        tray_icon.show()
        self.tray_icon = tray_icon

    def closeEvent(self, event) -> None:  # type: ignore[override]
        self.stop_server()
        return super().closeEvent(event)
