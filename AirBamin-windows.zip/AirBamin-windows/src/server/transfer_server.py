"""
Transfer Server - Based on existing hotspot.py
Handles file uploads from mobile browser
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import os
import json
from datetime import datetime
from pathlib import Path
import threading
import traceback

from core.config import Config
from core.license import LicenseManager


class TransferHandler(BaseHTTPRequestHandler):
    """Handle HTTP requests for file transfers"""
    
    # Increase timeout for large file uploads (10 minutes)
    timeout = 600
    
    config = None
    license_manager = None
    on_status_change = None
    on_transfer_complete = None
    on_upload_progress = None
    on_client_connected = None
    current_upload = {"active": False, "filename": "", "progress": 0, "size": 0, "completed": False, "completed_at": None, "cancelled": False}
    last_client_ip = None
    last_client_time = None
    session_active = False
    session_start_time = None
    upload_triggered = False
    upload_trigger_time = None
    upload_count = 0
    upload_cancelled = False
    uploaded_files_list = []  # Track uploaded files in current session
    _cached_upload_page = None  # Cache the upload page HTML for fast loading
    
    def log_message(self, format, *args):
        """Log HTTP requests"""
        print(f"[HTTP] {format % args}")
        
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        
    def do_GET(self):
        """Serve the upload page or API endpoints"""
        # Parse path without query parameters
        from urllib.parse import urlparse
        parsed_path = urlparse(self.path).path

        if self.path == '/' or self.path == '/upload':
            # Just serve the upload page - don't mark session as active yet
            client_ip = self.client_address[0]

            # Track that a client viewed the page (but not necessarily connected)
            self.last_client_ip = client_ip
            self.last_client_time = datetime.now().isoformat()
            
            print(f"[SESSION] 📱 Phone accessed upload page from {client_ip}")
            
            # Notify UI that phone opened the upload page
            if self.on_client_connected:
                self.on_client_connected(client_ip)

            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.send_header('Connection', 'close')  # Close connection after sending page for faster load
            self.end_headers()

            html = self.get_upload_page()
            self.wfile.write(html.encode('utf-8'))
            
        elif self.path == '/api/info':
            # Return server info for hosted UI
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            
            import socket
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
                s.close()
            except:
                local_ip = "0.0.0.0"
            
            self.wfile.write(json.dumps({
                "ip": local_ip,
                "port": self.server.server_port,
                "url": f"http://{local_ip}:{self.server.server_port}",
                "isPro": self.license_manager.is_pro(),
                "uploadFolder": str(self.config.get_upload_folder())
            }).encode())
            
        elif self.path == '/api/stats':
            # Return daily stats
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            
            stats = self.config.get_daily_stats()
            # Return 'size' for frontend compatibility
            response = {
                "count": stats.get("count", 0),
                "size": stats.get("total_bytes", 0),
                "date": stats.get("date")
            }
            print(f"[DEBUG] Stats from file: {stats}")
            print(f"[DEBUG] Returning to client: {response}")
            self.wfile.write(json.dumps(response).encode())
            
        elif self.path == '/api/qr':
            # Generate and return QR code as base64
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            
            import socket
            import qrcode
            from io import BytesIO
            import base64
            
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
                s.close()
            except:
                local_ip = "127.0.0.1"
            
            url = f"http://{local_ip}:{self.server.server_port}"
            
            qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white").convert('RGB')
            
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            qr_base64 = base64.b64encode(buffer.getvalue()).decode('ascii')
            
            self.wfile.write(json.dumps({
                "url": url,
                "qrCode": f"data:image/png;base64,{qr_base64}"
            }).encode())
            
        elif self.path == '/check-limit':
            # Check if user hit free tier limit
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            can_upload, message = self.config.check_upload_limit(self.license_manager.is_pro())
            self.wfile.write(json.dumps({
                "allowed": can_upload,
                "message": message
            }).encode())
            
        elif self.path == '/api/progress':
            # Return current upload progress
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()

            print(f"[API-PROGRESS] Returning: {self.current_upload}")
            self.wfile.write(json.dumps(self.current_upload).encode())
            
        elif self.path == '/api/connection':
            # Return last client connection info
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()

            connection_info = {
                "connected": self.last_client_ip is not None,
                "client_ip": self.last_client_ip,
                "last_seen": self.last_client_time,
                "session_active": self.session_active,
                "session_start": self.session_start_time,
                "upload_triggered": self.upload_triggered,
                "upload_trigger_time": self.upload_trigger_time,
                "uploaded_files": self.uploaded_files_list
            }
            print(f"[API-CONNECTION] Returning: {connection_info}")
            self.wfile.write(json.dumps(connection_info).encode())
            
        elif self.path == '/api/session/reset':
            # Reset session (generate new QR code)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            # Clear all state
            self.session_active = False
            self.session_start_time = None
            self.last_client_ip = None
            self.last_client_time = None
            self.upload_triggered = False
            self.upload_trigger_time = None
            self.current_upload = {"active": False, "filename": "", "progress": 0, "size": 0, "completed": False, "completed_at": None, "cancelled": False}
            self.upload_cancelled = False
            self.uploaded_files_list = []
            print("[SESSION] 🔄 Session reset - all state cleared, ready for new connection")

            self.wfile.write(json.dumps({"success": True, "message": "Session reset"}).encode())
            
        elif self.path == '/pc' or self.path == '/desktop' or parsed_path == '/pc' or parsed_path == '/desktop':
            # Serve PC control interface - redirect to welcome page
            self.send_response(301)
            self.send_header('Location', '/welcome.html')
            self.end_headers()

        elif parsed_path.endswith('.html'):
            # Serve HTML files from web directory
            try:
                web_path = Path(__file__).parent.parent / 'resources' / 'web'
                file_path = web_path / parsed_path.lstrip('/')
                print(f"[DEBUG] Looking for HTML at: {file_path}")

                if file_path.exists() and file_path.is_file():
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    self.send_response(200)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()
                    self.wfile.write(content.encode('utf-8'))
                    print(f"[DEBUG] Served {parsed_path} successfully")
                else:
                    self.send_error(404)
                    print(f"[ERROR] HTML file not found at {file_path}")
            except Exception as e:
                print(f"[ERROR] Exception serving HTML: {e}")
                self.send_error(500)

        elif parsed_path.endswith('.css'):
            # Serve CSS files
            try:
                web_path = Path(__file__).parent.parent / 'resources' / 'web'
                file_path = web_path / parsed_path.lstrip('/')
                print(f"[DEBUG] Looking for CSS at: {file_path}")

                if file_path.exists() and file_path.is_file():
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    self.send_response(200)
                    self.send_header('Content-type', 'text/css; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    self.wfile.write(content.encode('utf-8'))
                    print(f"[DEBUG] Served CSS {parsed_path} successfully")
                else:
                    self.send_error(404)
                    print(f"[ERROR] CSS file not found at {file_path}")
            except Exception as e:
                print(f"[ERROR] Exception serving CSS: {e}")
                self.send_error(500)

        elif parsed_path.endswith('.js'):
            # Serve JavaScript files
            try:
                web_path = Path(__file__).parent.parent / 'resources' / 'web'
                file_path = web_path / parsed_path.lstrip('/')
                print(f"[DEBUG] Looking for JS at: {file_path}")

                if file_path.exists() and file_path.is_file():
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    self.send_response(200)
                    self.send_header('Content-type', 'application/javascript; charset=utf-8')
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    self.wfile.write(content.encode('utf-8'))
                    print(f"[DEBUG] Served JS {parsed_path} successfully")
                else:
                    self.send_error(404)
                    print(f"[ERROR] JS file not found at {file_path}")
            except Exception as e:
                print(f"[ERROR] Exception serving JS: {e}")
                self.send_error(500)

        else:
            self.send_error(404)
            
    def do_POST(self):
        """Handle file upload and other POST requests"""
        if self.path == '/api/upload-start':
            # Mark that upload has been triggered - NOW the session is truly active
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()

            # Mark session as active when user actually starts uploading
            if not self.session_active:
                self.session_active = True
                self.session_start_time = datetime.now().isoformat()
                client_ip = self.client_address[0]
                print(f"[SESSION] 📱 ✅ Phone connected and started upload from {client_ip}")
                
                if self.on_client_connected:
                    self.on_client_connected(client_ip)
            
            self.upload_triggered = True
            self.upload_trigger_time = datetime.now().isoformat()
            self.upload_cancelled = False
            print(f"[INFO] UPLOAD TRIGGERED - Phone started uploading")
            
            self.wfile.write(json.dumps({"success": True}).encode())
            
        elif self.path == '/api/cancel-upload':
            # Cancel ongoing upload
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            self.upload_cancelled = True
            self.current_upload["active"] = False
            self.current_upload["cancelled"] = True
            self.current_upload["progress"] = 0
            print(f"[INFO] ⚠️ UPLOAD CANCELLED by user")
            
            self.wfile.write(json.dumps({"success": True, "message": "Upload cancelled"}).encode())
            
        elif self.path == '/upload':
            try:
                print(f"[UPLOAD] 📥 Received upload request from {self.client_address[0]}")
                
                # Check limits (free tier)
                can_upload, message = self.config.check_upload_limit(self.license_manager.is_pro())
                
                if not can_upload:
                    print(f"[UPLOAD] ❌ Upload limit reached: {message}")
                    self.send_response(403)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": message}).encode())
                    return
                
                # Parse multipart form data
                content_type = self.headers.get('Content-Type', '')
                print(f"[UPLOAD] Content-Type: {content_type}")
                
                if not content_type.startswith('multipart/form-data'):
                    print(f"[UPLOAD] ❌ Invalid Content-Type: {content_type}")
                    self.send_error(400, "Bad Request - Expected multipart/form-data")
                    return
                    
                # Get boundary - handle both formats
                if 'boundary=' not in content_type:
                    print(f"[UPLOAD] ❌ No boundary in Content-Type")
                    self.send_error(400, "Bad Request - No boundary specified")
                    return
                    
                boundary = content_type.split("boundary=")[1]
                if ';' in boundary:
                    boundary = boundary.split(';')[0]
                boundary = boundary.strip().encode()
                print(f"[UPLOAD] Boundary: {boundary[:50]}")
                
                # Read file data
                content_length = int(self.headers.get('Content-Length', 0))
                print(f"[UPLOAD] Content-Length: {content_length} bytes ({content_length / (1024*1024):.2f} MB)")
                
                # Check file size limit (free tier)
                max_size = self.license_manager.get_max_file_size()
                if not self.license_manager.is_pro() and content_length > max_size:
                    self.send_response(413)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({
                        "error": f"File too large. Free tier limit: {max_size // (1024*1024)}MB. Upgrade to Pro for unlimited."
                    }).encode())
                    return
                
                # Read data in chunks and report progress
                bytes_received = 0
                body_parts = []
                chunk_size = 131072  # 128KB chunks for stability (reduced from 256KB to prevent timeout)
                filename_for_progress = "file"
                
                # Mark upload as active
                self.current_upload["active"] = True
                self.current_upload["filename"] = "Uploading..."
                self.current_upload["progress"] = 0
                self.current_upload["size"] = content_length
                self.current_upload["completed"] = False
                self.current_upload["completed_at"] = None
                self.current_upload["cancelled"] = False

                print(f"[UPLOAD] 🚀 Starting upload - Size: {content_length} bytes")
                print(f"[UPLOAD] Using {chunk_size / 1024}KB chunks for stable transfer")
                
                try:
                    while bytes_received < content_length:
                        # Check if cancelled
                        if self.upload_cancelled:
                            print(f"[UPLOAD] ⚠️ Upload cancelled - aborting")
                            self.send_response(499)  # Client Closed Request
                            self.send_header('Content-type', 'application/json')
                            self.end_headers()
                            self.wfile.write(json.dumps({"error": "Upload cancelled"}).encode())
                            self.current_upload["active"] = False
                            self.current_upload["cancelled"] = True
                            self.upload_cancelled = False
                            return
                        
                        try:
                            remaining = content_length - bytes_received
                            to_read = min(chunk_size, remaining)
                            chunk = self.rfile.read(to_read)
                            
                            if not chunk:
                                print(f"[UPLOAD] ⚠️ Connection closed by client at {bytes_received}/{content_length} bytes")
                                break
                                
                            body_parts.append(chunk)
                            bytes_received += len(chunk)
                            
                            # Update progress
                            progress_percent = int((bytes_received / content_length) * 100)
                            self.current_upload["progress"] = progress_percent
                            
                            # Report progress every 10%
                            if progress_percent % 10 == 0 and self.on_upload_progress:
                                self.on_upload_progress(filename_for_progress, bytes_received, content_length)
                                
                        except Exception as read_error:
                            print(f"[UPLOAD] ❌ Error reading chunk: {read_error}")
                            raise
                            
                except Exception as upload_error:
                    print(f"[UPLOAD] ❌ Upload failed during transfer: {upload_error}")
                    self.send_response(500)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": f"Upload failed: {str(upload_error)}"}).encode())
                    self.current_upload["active"] = False
                    return
                
                print(f"[UPLOAD] ✅ Received {bytes_received} bytes successfully")
                body = b''.join(body_parts)
                
                # Extract filename and file data
                parts = body.split(boundary)
                
                for part in parts:
                    if b'Content-Disposition' in part:
                        # Extract filename
                        if b'filename="' in part:
                            filename_start = part.find(b'filename="') + 10
                            filename_end = part.find(b'"', filename_start)
                            filename = part[filename_start:filename_end].decode()
                            
                            # Extract file content
                            file_start = part.find(b'\r\n\r\n') + 4
                            file_end = len(part) - 2
                            file_data = part[file_start:file_end]
                            
                            # Save file
                            upload_folder = self.config.get_upload_folder()
                            upload_folder.mkdir(exist_ok=True)
                            
                            # Add timestamp to avoid conflicts
                            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                            safe_filename = f"{timestamp}_{filename}"
                            filepath = upload_folder / safe_filename
                            
                            with open(filepath, 'wb') as f:
                                f.write(file_data)

                            print(f"[SUCCESS] ✅ File saved: {safe_filename} ({len(file_data)} bytes)")

                            # Update stats
                            self.config.record_transfer(len(file_data))
                            print(f"[STATS] Stats updated - new transfer recorded")

                            # Add to uploaded files list
                            self.uploaded_files_list.append({
                                "filename": filename,
                                "size": len(file_data),
                                "timestamp": datetime.now().isoformat()
                            })

                            # Update progress with filename
                            self.current_upload["filename"] = filename
                            self.current_upload["progress"] = 100
                            self.current_upload["active"] = True  # Keep active so UI sees it
                            self.current_upload["completed"] = True
                            self.current_upload["completed_at"] = datetime.now().isoformat()
                            self.current_upload["cancelled"] = False

                            # Increment upload counter
                            self.upload_count += 1

                            # Callback
                            if self.on_transfer_complete:
                                self.on_transfer_complete(filename, len(file_data))

                            # Success response
                            self.send_response(200)
                            self.send_header('Content-type', 'application/json')
                            self.send_header('Connection', 'keep-alive')
                            self.send_header('Access-Control-Allow-Origin', '*')
                            self.end_headers()
                            self.wfile.write(json.dumps({
                                "success": True,
                                "filename": filename,
                                "size": len(file_data)
                            }).encode())

                            print(f"[UPLOAD] ✅ Upload #{self.upload_count} complete: {filename}")
                            print(f"[UPLOAD] State kept visible - UI will see: active=True, progress=100, completed=True")

                            return
                
                self.send_error(400, "No file found")
                
            except Exception as e:
                # Log the full error for debugging
                print(f"[ERROR] Upload failed: {e}")
                traceback.print_exc()

                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())

                # Clear upload state
                self.current_upload["active"] = False
                self.current_upload["progress"] = 0
        else:
            self.send_error(404)
            
    def get_upload_page(self):
        """Return the mobile upload page HTML (cached for performance)"""
        # Use cached version if available
        if TransferHandler._cached_upload_page is not None:
            return TransferHandler._cached_upload_page
            
        # Read from resources and cache it
        template_path = Path(__file__).parent.parent / "resources" / "web" / "upload.html"

        if template_path.exists():
            with open(template_path, 'r', encoding='utf-8') as f:
                html = f.read()
                TransferHandler._cached_upload_page = html  # Cache for next time
                return html
        else:
            # Inline HTML (simplified version of hotspot.py)
            return '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AirBamin - Upload Files</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
            font-size: 28px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .upload-area {
            border: 3px dashed #667eea;
            border-radius: 15px;
            padding: 40px 20px;
            text-align: center;
            background: #f8f9ff;
            margin: 20px 0;
            cursor: pointer;
            transition: all 0.3s;
        }
        .upload-area:hover { border-color: #764ba2; background: #f0f1ff; }
        .upload-area.dragover { border-color: #10b981; background: #d1fae5; }
        input[type="file"] { display: none; }
        .file-label {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s;
        }
        .file-label:hover { transform: scale(1.05); }
        .progress {
            display: none;
            margin-top: 20px;
        }
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e5e7eb;
            border-radius: 15px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981 0%, #059669 100%);
            width: 0%;
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .status {
            margin-top: 15px;
            text-align: center;
            font-size: 14px;
        }
        .success { color: #10b981; }
        .error { color: #ef4444; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📱 AirBamin</h1>
        <p class="subtitle">Upload files to your PC</p>
        
        <div class="upload-area" id="uploadArea">
            <div style="font-size: 48px; margin-bottom: 15px;">📁</div>
            <label for="fileInput" class="file-label">Choose Files</label>
            <input type="file" id="fileInput" multiple>
            <p style="margin-top: 15px; color: #666; font-size: 13px;">
                or drag and drop files here
            </p>
        </div>
        
        <div class="progress" id="progress">
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill">0%</div>
            </div>
        </div>
        
        <div class="status" id="status"></div>
    </div>
    
    <script>
        const fileInput = document.getElementById('fileInput');
        const uploadArea = document.getElementById('uploadArea');
        const progress = document.getElementById('progress');
        const progressFill = document.getElementById('progressFill');
        const status = document.getElementById('status');
        
        fileInput.addEventListener('change', handleFiles);
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            fileInput.files = e.dataTransfer.files;
            handleFiles();
        });
        
        async function handleFiles() {
            const files = fileInput.files;
            if (files.length === 0) return;
            
            for (let i = 0; i < files.length; i++) {
                await uploadFile(files[i]);
            }
        }
        
        async function uploadFile(file) {
            const formData = new FormData();
            formData.append('file', file);
            
            progress.style.display = 'block';
            status.innerHTML = `Uploading ${file.name}...`;
            status.className = 'status';
            
            // Notify server that upload is starting (triggers QR refresh on PC)
            try {
                await fetch('/api/upload-start', { method: 'POST' });
            } catch (e) {
                console.log('Could not notify upload start');
            }
            
            try {
                const xhr = new XMLHttpRequest();
                
                xhr.upload.addEventListener('progress', (e) => {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        progressFill.style.width = percent + '%';
                        progressFill.textContent = percent + '%';
                    }
                });
                
                xhr.addEventListener('load', () => {
                    if (xhr.status === 200) {
                        status.innerHTML = `✅ ${file.name} uploaded successfully!`;
                        status.className = 'status success';
                    } else if (xhr.status === 403) {
                        const response = JSON.parse(xhr.responseText);
                        status.innerHTML = `❌ ${response.error}`;
                        status.className = 'status error';
                    } else if (xhr.status === 413) {
                        const response = JSON.parse(xhr.responseText);
                        status.innerHTML = `❌ ${response.error}`;
                        status.className = 'status error';
                    } else {
                        status.innerHTML = `❌ Upload failed`;
                        status.className = 'status error';
                    }
                    
                    setTimeout(() => {
                        progress.style.display = 'none';
                        progressFill.style.width = '0%';
                    }, 2000);
                });
                
                xhr.addEventListener('error', () => {
                    status.innerHTML = '❌ Network error';
                    status.className = 'status error';
                });
                
                xhr.open('POST', '/upload');
                xhr.send(formData);
            } catch (error) {
                status.innerHTML = `❌ Error: ${error.message}`;
                status.className = 'status error';
            }
        }
    </script>
</body>
</html>'''


class TransferServer:
    """File transfer server wrapper"""
    
    def __init__(self, port=8080):
        self.port = port
        self.server = None
        self.config = Config()
        self.license_manager = LicenseManager()
        self.on_status_change = None
        self.on_transfer_complete = None
        self.on_upload_progress = None
        self.on_client_connected = None
        
    def start(self):
        """Start the HTTP server"""
        # Reset all class variables to ensure clean state
        TransferHandler.current_upload = {"active": False, "filename": "", "progress": 0, "size": 0, "completed": False, "completed_at": None, "cancelled": False}
        TransferHandler.last_client_ip = None
        TransferHandler.last_client_time = None
        TransferHandler.session_active = False
        TransferHandler.session_start_time = None
        TransferHandler.upload_triggered = False
        TransferHandler.upload_trigger_time = None
        TransferHandler.upload_count = 0
        TransferHandler.upload_cancelled = False
        TransferHandler.uploaded_files_list = []
        
        # Set class variables for handler
        TransferHandler.config = self.config
        TransferHandler.license_manager = self.license_manager
        TransferHandler.on_status_change = self.on_status_change
        TransferHandler.on_transfer_complete = self.on_transfer_complete
        TransferHandler.on_upload_progress = self.on_upload_progress
        TransferHandler.on_client_connected = self.on_client_connected
        
        print("[SERVER] 🚀 Starting fresh server - all state reset")
        
        self.server = HTTPServer(('0.0.0.0', self.port), TransferHandler)
        self.server.serve_forever()
        
    def stop(self):
        """Stop the server"""
        if self.server:
            self.server.shutdown()
