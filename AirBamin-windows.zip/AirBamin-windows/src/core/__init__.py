"""Core package initialization"""
