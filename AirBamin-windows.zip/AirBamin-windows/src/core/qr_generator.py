"""
QR Code Generator
Generates QR codes for network URLs
"""

import qrcode
from PIL import Image, ImageDraw
from pathlib import Path


class QRGenerator:
    """Generate QR codes for file transfer URLs"""
    
    def __init__(self):
        self.box_size = 8
        self.border = 1
        
    def generate(self, url, output_path=None):
        """
        Generate QR code for given URL
        
        Args:
            url: The URL to encode
            output_path: Optional path to save QR code image
            
        Returns:
            PIL Image object
        """
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=self.box_size,
            border=self.border,
        )
        
        qr.add_data(url)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to RGB mode for PIL operations
        img = img.convert('RGB')
        
        # Add some padding and styling
        img = self.add_border(img, color="white", size=15)
        
        if output_path:
            img.save(output_path)
            
        return img
        
    def add_border(self, img, color="white", size=20):
        """Add border around QR code"""
        width, height = img.size
        new_width = width + (size * 2)
        new_height = height + (size * 2)
        
        new_img = Image.new("RGB", (new_width, new_height), color)
        new_img.paste(img, (size, size))
        
        return new_img
        
    def generate_with_logo(self, url, logo_path, output_path=None):
        """
        Generate QR code with logo in center
        
        Args:
            url: The URL to encode
            logo_path: Path to logo image
            output_path: Optional path to save QR code image
            
        Returns:
            PIL Image object
        """
        # Generate base QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,  # High correction for logo
            box_size=self.box_size,
            border=self.border,
        )
        
        qr.add_data(url)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white").convert('RGB')
        
        # Add logo
        try:
            logo = Image.open(logo_path)
            
            # Calculate logo size (max 25% of QR code)
            qr_width, qr_height = img.size
            logo_max_size = qr_width // 4
            
            # Resize logo
            logo.thumbnail((logo_max_size, logo_max_size), Image.Resampling.LANCZOS)
            
            # Calculate position (center)
            logo_pos = (
                (qr_width - logo.size[0]) // 2,
                (qr_height - logo.size[1]) // 2
            )
            
            # Paste logo
            img.paste(logo, logo_pos)
        except Exception as e:
            print(f"Could not add logo: {e}")
        
        # Add border
        img = self.add_border(img, color="white", size=20)
        
        if output_path:
            img.save(output_path)
            
        return img
