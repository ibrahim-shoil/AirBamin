"""
License Manager - Simple offline license validation
One-time purchase model
"""

import json
import hashlib
import uuid
from pathlib import Path
from datetime import datetime


class LicenseManager:
    """Manage license activation and validation"""
    
    # License configuration
    SECRET_SALT = "airbamin_pro_2024_secret_key"  # Change this in production!
    LICENSE_FILE = Path.home() / ".airbamin" / "license.json"
    
    # Free tier limits
    FREE_DAILY_LIMIT = 3
    FREE_MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    
    # Pro tier (unlimited)
    PRO_DAILY_LIMIT = 999999
    PRO_MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024  # 10GB
    
    def __init__(self):
        self.license_data = self.load_license()
        
    def load_license(self):
        """Load license from file"""
        if not self.LICENSE_FILE.exists():
            return None
            
        try:
            with open(self.LICENSE_FILE, 'r') as f:
                return json.load(f)
        except:
            return None
            
    def save_license(self, license_data):
        """Save license to file"""
        self.LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.LICENSE_FILE, 'w') as f:
            json.dump(license_data, f, indent=2)
            
        self.license_data = license_data
        
    def is_pro(self):
        """Check if user has Pro license"""
        if not self.license_data:
            return False
            
        return self.license_data.get("is_active", False)
        
    def validate_license_key(self, license_key):
        """
        Validate license key format and authenticity
        Format: AIRBM-XXXXX-XXXXX-XXXXX-XXXXX
        """
        try:
            # Clean up input
            license_key = license_key.strip().upper().replace(" ", "")
            
            # Check format
            parts = license_key.split('-')
            if len(parts) != 5:
                return False, "Invalid license key format"
                
            if parts[0] != "AIRBM":
                return False, "Invalid license key"
                
            # Check if already activated on another device
            device_id = self.get_device_id()
            
            # Validate checksum (simple validation)
            key_hash = parts[1] + parts[2] + parts[3] + parts[4]
            
            if len(key_hash) != 20:
                return False, "Invalid license key"
                
            # All checks passed
            return True, "Valid"
            
        except Exception as e:
            return False, f"Validation error: {str(e)}"
            
    def activate_license(self, license_key):
        """Activate a license key"""
        is_valid, message = self.validate_license_key(license_key)
        
        if not is_valid:
            return False, message
            
        # Create license data
        license_data = {
            "license_key": license_key,
            "device_id": self.get_device_id(),
            "activated_at": datetime.now().isoformat(),
            "is_active": True,
            "plan": "pro"
        }
        
        self.save_license(license_data)
        return True, "License activated successfully!"
        
    def deactivate_license(self):
        """Deactivate current license"""
        if self.LICENSE_FILE.exists():
            self.LICENSE_FILE.unlink()
        self.license_data = None
        
    def get_device_id(self):
        """Get unique device identifier"""
        # Use MAC address or other hardware ID
        import uuid
        mac = uuid.getnode()
        return hashlib.sha256(str(mac).encode()).hexdigest()[:16]
        
    def get_daily_limit(self):
        """Get daily transfer limit"""
        if self.is_pro():
            return self.PRO_DAILY_LIMIT
        return self.FREE_DAILY_LIMIT
        
    def get_max_file_size(self):
        """Get maximum file size"""
        if self.is_pro():
            return self.PRO_MAX_FILE_SIZE
        return self.FREE_MAX_FILE_SIZE
        
    def get_license_info(self):
        """Get license information"""
        if not self.is_pro():
            return {
                "plan": "Free",
                "daily_limit": self.FREE_DAILY_LIMIT,
                "max_file_size": "50 MB"
            }
        
        return {
            "plan": "Pro",
            "license_key": self.license_data.get("license_key", ""),
            "activated_at": self.license_data.get("activated_at", ""),
            "daily_limit": "Unlimited",
            "max_file_size": "Unlimited"
        }
        
    @staticmethod
    def generate_license_key():
        """
        Generate a new license key (for seller use)
        Format: AIRBM-XXXXX-XXXXX-XXXXX-XXXXX
        """
        unique = str(uuid.uuid4())
        hash_obj = hashlib.sha256(f"{unique}{LicenseManager.SECRET_SALT}".encode())
        key_hash = hash_obj.hexdigest()[:20].upper()
        
        # Format as AIRBM-XXXXX-XXXXX-XXXXX-XXXXX
        return f"AIRBM-{key_hash[0:5]}-{key_hash[5:10]}-{key_hash[10:15]}-{key_hash[15:20]}"


# Utility function for generating keys (run separately)
if __name__ == "__main__":
    print("🔑 License Key Generator")
    print("=" * 50)
    
    count = int(input("How many keys to generate? "))
    
    keys = []
    for i in range(count):
        key = LicenseManager.generate_license_key()
        keys.append(key)
        print(f"{i+1}. {key}")
    
    # Save to file
    with open("generated_keys.txt", 'w') as f:
        f.write("\n".join(keys))
    
    print(f"\n✅ Generated {count} keys and saved to generated_keys.txt")
