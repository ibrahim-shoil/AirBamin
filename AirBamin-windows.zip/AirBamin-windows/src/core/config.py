"""
Configuration Manager
Handles app settings, usage tracking, and limits
"""

import json
from pathlib import Path
from datetime import date, datetime


class Config:
    """Application configuration and settings"""
    
    CONFIG_DIR = Path.home() / ".airbamin"
    CONFIG_FILE = CONFIG_DIR / "config.json"
    USAGE_FILE = CONFIG_DIR / "usage.json"
    
    DEFAULT_CONFIG = {
        "upload_folder": str(Path.home() / "AirBamin Uploads"),
        "port": 8080,
        "auto_start": False,
        "minimize_to_tray": True,
        "theme": "light"
    }
    
    def __init__(self):
        self.config = self.load_config()
        self.ensure_upload_folder()
        
    def load_config(self):
        """Load configuration from file"""
        if not self.CONFIG_FILE.exists():
            self.save_config(self.DEFAULT_CONFIG)
            return self.DEFAULT_CONFIG.copy()
            
        try:
            with open(self.CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            return self.DEFAULT_CONFIG.copy()
            
    def save_config(self, config=None):
        """Save configuration to file"""
        if config is None:
            config = self.config
            
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        
        with open(self.CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
            
    def get(self, key, default=None):
        """Get configuration value"""
        return self.config.get(key, default)
        
    def set(self, key, value):
        """Set configuration value"""
        self.config[key] = value
        self.save_config()
        
    def get_upload_folder(self):
        """Get upload folder path"""
        folder = Path(self.config.get("upload_folder", self.DEFAULT_CONFIG["upload_folder"]))
        folder.mkdir(parents=True, exist_ok=True)
        return folder
        
    def set_upload_folder(self, folder_path):
        """Set upload folder path"""
        self.set("upload_folder", str(folder_path))
        
    def get_port(self):
        """Get server port"""
        return self.config.get("port", 8080)
        
    def ensure_upload_folder(self):
        """Ensure upload folder exists"""
        folder = self.get_upload_folder()
        folder.mkdir(parents=True, exist_ok=True)
        
    def get_daily_stats(self):
        """Get today's usage statistics"""
        if not self.USAGE_FILE.exists():
            return {"date": str(date.today()), "count": 0, "total_bytes": 0}
            
        try:
            with open(self.USAGE_FILE, 'r') as f:
                data = json.load(f)
                
            # Reset if new day
            if data.get("date") != str(date.today()):
                data = {"date": str(date.today()), "count": 0, "total_bytes": 0}
                self.save_usage(data)
                
            return data
        except:
            return {"date": str(date.today()), "count": 0, "total_bytes": 0}
            
    def save_usage(self, data):
        """Save usage data"""
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        
        with open(self.USAGE_FILE, 'w') as f:
            json.dump(data, f, indent=2)
            
    def record_transfer(self, file_size):
        """Record a file transfer"""
        stats = self.get_daily_stats()
        stats["count"] += 1
        stats["total_bytes"] += file_size
        stats["last_transfer"] = datetime.now().isoformat()
        self.save_usage(stats)
        
    def check_upload_limit(self, is_pro):
        """Check if upload is allowed (for free tier)"""
        if is_pro:
            return True, "Pro user - unlimited"
            
        stats = self.get_daily_stats()
        
        # Free tier: 3 transfers per day
        if stats["count"] >= 3:
            return False, "Daily limit reached (3/day). Upgrade to Pro for unlimited transfers!"
            
        return True, f"Transfer {stats['count'] + 1}/3 today"
        
    def reset_usage(self):
        """Reset usage stats (for testing)"""
        data = {"date": str(date.today()), "count": 0, "total_bytes": 0}
        self.save_usage(data)
