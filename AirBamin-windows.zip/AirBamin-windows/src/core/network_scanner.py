"""
Network Scanner - Detect devices on local network
"""

import socket
import subprocess
import re
from typing import List, Dict, Optional


class NetworkScanner:
    """Scan local network for connected devices"""
    
    def __init__(self):
        self.known_devices = set()
        
    def get_network_prefix(self) -> Optional[str]:
        """Get network prefix (e.g., 192.168.1)"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            local_ip = sock.getsockname()[0]
            sock.close()
            
            # Get first 3 octets (e.g., 192.168.1 from 192.168.1.11)
            parts = local_ip.split('.')
            if len(parts) == 4:
                return f"{parts[0]}.{parts[1]}.{parts[2]}"
            return None
        except:
            return None
    
    def scan_arp_table(self) -> List[Dict[str, str]]:
        """Scan ARP table to find connected devices"""
        devices = []
        
        try:
            # Use arp -a command to get connected devices
            result = subprocess.run(['arp', '-a'], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.split('\n')
                
                for line in lines:
                    # Match IP and MAC address pattern
                    # Example: 192.168.1.2      00-11-22-33-44-55     dynamic
                    match = re.search(r'(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F-]+)\s+(\w+)', line)
                    
                    if match:
                        ip = match.group(1)
                        mac = match.group(2)
                        type_ = match.group(3)
                        
                        # Only include dynamic entries (actual connected devices)
                        if type_.lower() == 'dynamic':
                            devices.append({
                                'ip': ip,
                                'mac': mac,
                                'type': type_
                            })
            
        except Exception as e:
            print(f"[NETWORK-SCAN] Error scanning ARP: {e}")
        
        return devices
    
    def detect_new_devices(self) -> List[Dict[str, str]]:
        """Detect newly connected devices"""
        current_devices = self.scan_arp_table()
        current_ips = {d['ip'] for d in current_devices}
        
        # Find new devices
        new_ips = current_ips - self.known_devices
        new_devices = [d for d in current_devices if d['ip'] in new_ips]
        
        # Update known devices
        self.known_devices = current_ips
        
        return new_devices
    
    def get_device_count(self) -> int:
        """Get number of connected devices on network"""
        devices = self.scan_arp_table()
        return len(devices)
    
    def is_device_online(self, ip: str) -> bool:
        """Check if a specific IP is online"""
        devices = self.scan_arp_table()
        return any(d['ip'] == ip for d in devices)
    
    def get_likely_phone_devices(self) -> List[Dict[str, str]]:
        """Get devices that are likely phones (heuristic based on MAC vendor)"""
        devices = self.scan_arp_table()
        phone_devices = []
        
        # Common phone MAC prefixes (Apple, Samsung, etc.)
        phone_prefixes = [
            # Apple devices
            '00-03-93', '00-0D-93', '00-17-F2', '00-19-E3', '00-1B-63', '00-1E-C2',
            '00-1F-F3', '00-21-E9', '00-23-12', '00-23-32', '00-23-6C', '00-24-36',
            '00-25-00', '00-25-BC', '00-26-08', '00-26-4A', '00-26-B0', '00-26-BB',
            '00-30-65', '00-3E-E1', '00-50-E4', '00-61-71', '00-C6-10', '04-0C-CE',
            '04-15-52', '04-1E-64', '04-26-65', '04-48-9A', '04-54-53', '04-69-F8',
            '04-DB-56', '04-E5-36', '04-F1-3E', '04-F7-E4',
            # Samsung devices
            '00-00-F0', '00-12-47', '00-12-FB', '00-13-77', '00-15-99', '00-16-32',
            '00-16-6B', '00-16-6C', '00-17-C9', '00-17-D5', '00-18-AF', '00-1A-8A',
            # Add more as needed
        ]
        
        for device in devices:
            mac = device['mac'].upper().replace('-', ':')
            mac_prefix = ':'.join(mac.split(':')[:3])
            
            # Check if MAC matches known phone vendors
            if any(prefix.replace('-', ':') in mac_prefix for prefix in phone_prefixes):
                device['likely_phone'] = True
                phone_devices.append(device)
        
        return phone_devices
