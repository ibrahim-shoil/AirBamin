# AirBamin Resources

This folder contains app resources:
- icons/
- images/
- web/ (mobile upload interface)
