// AirBamin - Main Application JavaScript

// State
let pollInterval = null;
let lastKnownIP = null;
let lastConnectionTime = null;
let lastUploadTrigger = null;

// Navigation
function navigate(page) {
    window.location.href = page;
}

// API Functions
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        const transferCountEl = document.getElementById('transferCount');
        const transferSizeEl = document.getElementById('transferSize');

        if (transferCountEl) {
            transferCountEl.textContent = data.count || 0;
        }

        if (transferSizeEl) {
            const sizeMB = data.size ? (data.size / (1024 * 1024)).toFixed(1) : '0.0';
            transferSizeEl.textContent = sizeMB + ' MB';
        }
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function checkLicense() {
    try {
        const response = await fetch('/api/info');
        const data = await response.json();

        const licenseBadge = document.getElementById('licenseBadge');
        const upgradeButton = document.getElementById('upgradeButton');

        if (licenseBadge) {
            if (data.isPro) {
                licenseBadge.textContent = 'PRO';
                licenseBadge.className = 'badge badge-gold';
                if (upgradeButton) upgradeButton.classList.add('hidden');
            } else {
                licenseBadge.textContent = 'FREE';
                licenseBadge.className = 'badge badge-outline';
                if (upgradeButton) upgradeButton.classList.remove('hidden');
            }
        }

        const uploadPath = document.getElementById('uploadPath');
        if (uploadPath && data.uploadFolder) {
            uploadPath.textContent = 'Files will be saved to: ' + data.uploadFolder;
        }
    } catch (error) {
        console.error('Failed to check license:', error);
    }
}

async function loadQRCode() {
    try {
        const response = await fetch('/api/qr');
        const data = await response.json();

        const qrImage = document.getElementById('qrImage');
        const qrUrl = document.getElementById('qrUrl');

        if (qrImage) qrImage.src = data.qrCode;
        if (qrUrl) qrUrl.textContent = data.url;
    } catch (error) {
        console.error('Error generating QR code:', error);
        setStatus('Error generating QR code', 'error');
    }
}

async function checkUploadProgress() {
    try {
        const response = await fetch('/api/progress');
        const data = await response.json();

        if (data.active) {
            console.log(`[PROGRESS] Upload state:`, data);

            // Show progress bar
            showProgress(data.filename, data.progress);

            if (data.completed && data.progress === 100) {
                // Upload just completed!
                console.log(`[PROGRESS] ✅ Upload complete: ${data.filename}`);
                setStatus(`✅ Upload complete! ${data.filename}`, 'success');

                // Reload stats
                await loadStats();
                const statsText = document.getElementById('statsText');
                if (statsText) {
                    const statsResponse = await fetch('/api/stats');
                    const statsData = await statsResponse.json();
                    statsText.textContent = `Transfers today: ${statsData.count || 0}`;
                    console.log(`[PROGRESS] Stats updated: ${statsData.count} transfers`);
                }

                // Clear state after 3 seconds
                setTimeout(async () => {
                    console.log('[PROGRESS] Clearing completed upload state...');
                    await fetch('/api/session/reset', { method: 'GET' });
                    hideProgress();
                    setStatus('Ready for next upload!', 'info');
                }, 3000);
            } else if (data.progress > 0 && data.progress < 100) {
                // Upload in progress
                setStatus(`Receiving file: ${data.filename} (${data.progress}%)`, 'info');
            } else if (data.progress === 0) {
                // Just started
                setStatus(`Upload starting: ${data.filename}...`, 'info');
            }
        } else {
            // No active upload
            hideProgress();
        }
    } catch (error) {
        console.error('[PROGRESS] Check failed:', error);
    }
}

async function monitorNetwork() {
    try {
        const response = await fetch('/api/info');
        const data = await response.json();

        const currentIP = data.ip;

        // Detect IP change (network switch)
        if (lastKnownIP && lastKnownIP !== currentIP && currentIP !== '0.0.0.0') {
            console.log('Network changed:', lastKnownIP, '->', currentIP);
            setStatus(`Network changed! New IP: ${currentIP}`, 'info');
            await loadQRCode();
        }

        // Store current IP
        if (currentIP !== '0.0.0.0') {
            lastKnownIP = currentIP;
        }

        // Show warning if no network
        if (currentIP === '0.0.0.0' || currentIP === '127.0.0.1') {
            const mode = localStorage.getItem('selectedMode');
            if (mode === 'hotspot') {
                setStatus('Waiting for hotspot connection from PC...', 'info');
            } else {
                setStatus('No network detected. Connect to WiFi.', 'info');
            }
        }
    } catch (error) {
        console.error('Network monitor failed:', error);
    }
}

async function checkPhoneConnection() {
    try {
        const response = await fetch('/api/connection');
        const data = await response.json();

        if (data.session_active && data.client_ip) {
            if (!lastConnectionTime || lastConnectionTime !== data.session_start) {
                lastConnectionTime = data.session_start;
                console.log(`[CONNECTION] ✅ Phone connected from: ${data.client_ip}`);
                setStatus(`✅ Phone Connected! (${data.client_ip})`, 'success');

                const qrWrapper = document.querySelector('.qr-wrapper');
                if (qrWrapper) {
                    qrWrapper.style.opacity = '0.5';
                    qrWrapper.style.border = '3px solid #10b981';
                }
            }

            if (data.upload_triggered && data.upload_trigger_time) {
                if (!lastUploadTrigger || lastUploadTrigger !== data.upload_trigger_time) {
                    lastUploadTrigger = data.upload_trigger_time;
                    console.log('[CONNECTION] 🚀 Phone started uploading files');
                    setStatus('🚀 Receiving files from phone...', 'info');
                }
            }
        } else if (!data.session_active && lastConnectionTime) {
            console.log('[CONNECTION] ✅ Upload complete! Refreshing for next device');
            setStatus('✅ Upload complete! Ready for next device', 'success');

            // Reset state properly
            lastConnectionTime = null;
            lastUploadTrigger = null;
            lastKnownIP = null;

            await loadQRCode();

            const qrWrapper = document.querySelector('.qr-wrapper');
            if (qrWrapper) {
                qrWrapper.style.opacity = '1';
                qrWrapper.style.border = 'none';
            }

            // Reload stats after upload completes
            await loadStats();
            const statsText = document.getElementById('statsText');
            if (statsText) {
                const statsResponse = await fetch('/api/stats');
                const statsData = await statsResponse.json();
                statsText.textContent = `Transfers today: ${statsData.count || 0}`;
                console.log(`[CONNECTION] Stats updated: ${statsData.count} transfers`);
            }

            setTimeout(() => {
                if (!lastConnectionTime) {
                    setStatus('Server running - Waiting for connections...', 'info');
                }
            }, 3000);
        } else if (!data.session_active) {
            const qrWrapper = document.querySelector('.qr-wrapper');
            if (qrWrapper) {
                qrWrapper.style.opacity = '1';
                qrWrapper.style.border = 'none';
            }
        }
    } catch (error) {
        console.error('[CONNECTION] Check failed:', error);
    }
}

async function resetSession() {
    try {
        console.log('Resetting session...');
        const response = await fetch('/api/session/reset');

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('Reset response:', data);

        if (data.success) {
            lastConnectionTime = null;
            lastUploadTrigger = null;
            lastKnownIP = null;

            await loadQRCode();

            setStatus('New session started! Scan QR code to connect.', 'info');

            const qrWrapper = document.querySelector('.qr-wrapper');
            if (qrWrapper) {
                qrWrapper.style.opacity = '1';
                qrWrapper.style.border = 'none';
            }

            console.log('Session reset successfully');
        } else {
            throw new Error(data.message || 'Reset failed');
        }
    } catch (error) {
        console.error('Session reset error:', error);
        setStatus(`Reset failed: ${error.message}`, 'error');
    }
}

// UI Functions
function setStatus(text, variant) {
    const statusText = document.getElementById('statusText');
    if (statusText) {
        statusText.textContent = text;
        statusText.dataset.variant = variant;
    }
}

function showProgress(filename, percent) {
    const progressWrapper = document.getElementById('progressWrapper');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');

    if (progressWrapper) progressWrapper.classList.remove('hidden');
    if (progressBar) progressBar.style.width = `${percent}%`;
    if (progressText) progressText.textContent = `Uploading ${filename}: ${percent}%`;
}

function hideProgress() {
    const progressWrapper = document.getElementById('progressWrapper');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');

    if (progressWrapper) progressWrapper.classList.add('hidden');
    if (progressBar) progressBar.style.width = '0%';
    if (progressText) progressText.textContent = '';
}

function startPolling() {
    if (pollInterval) {
        console.log('[POLLING] ⚠️ Clearing existing interval');
        clearInterval(pollInterval);
    }

    console.log('[POLLING] ✓ Setting up new polling interval...');

    let pollCount = 0;
    pollInterval = setInterval(async () => {
        pollCount++;
        console.log(`[POLLING] 🔄 Poll #${pollCount} - Checking status...`);

        try {
            // Check connection first
            const connResponse = await fetch('/api/connection');
            const connData = await connResponse.json();
            console.log(`[POLLING] Poll #${pollCount} - Connection data:`, connData);

            // Check progress
            const progResponse = await fetch('/api/progress');
            const progData = await progResponse.json();
            console.log(`[POLLING] Poll #${pollCount} - Progress data:`, progData);

            await checkPhoneConnection();
            await checkUploadProgress();
            await loadStats();

            // Update stats text on the page
            const statsText = document.getElementById('statsText');
            if (statsText) {
                const response = await fetch('/api/stats');
                const data = await response.json();
                statsText.textContent = `Transfers today: ${data.count || 0}`;
            }

            console.log(`[POLLING] Poll #${pollCount} - ✓ Complete`);
        } catch (error) {
            console.error(`[POLLING] Poll #${pollCount} - ❌ Error:`, error);
        }
    }, 1000); // Poll every 1 second

    console.log('[POLLING] ✓ Polling started! Interval ID:', pollInterval);
}

function stopPolling() {
    if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
    }
}

// Action Handlers
function viewFiles() {
    console.log('[ACTION] View files clicked');
    fetch('/api/info')
        .then(res => res.json())
        .then(data => {
            alert('Upload folder: ' + data.uploadFolder + '\n\nNote: Folder opening via web browser is not supported. Please navigate to this path manually.');
        })
        .catch(err => console.error('Failed to get folder info:', err));
}

function changeNetwork() {
    console.log('[ACTION] Change network clicked');
    window.location.href = 'mode-selection.html';
}

function openSettings() {
    console.log('[ACTION] Settings clicked');
    alert('Settings feature coming soon!');
}

function upgradeAccount() {
    console.log('[ACTION] Upgrade clicked');
    alert('Visit our website to upgrade to PRO for unlimited transfers!');
}

// Cleanup
window.addEventListener('beforeunload', stopPolling);
